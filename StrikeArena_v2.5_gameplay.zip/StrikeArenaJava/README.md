# Strike Arena — Java / LibGDX

Port inicial do protótipo HTML enviado para Java com LibGDX, preparado para desktop e Android.

## Requisitos
- JDK 17
- Android Studio (para compilar Android)
- Gradle 8.7+ (ou use o Gradle integrado do Android Studio)

## Executar no PC
Na pasta do projeto:
```bash
gradle :lwjgl3:run
```

## Abrir no Android
1. Abra a pasta do projeto no Android Studio.
2. Aguarde a sincronização do Gradle.
3. Selecione a configuração `android` e execute em um dispositivo/emulador Android.

## Controles
### PC
- WASD: movimentar
- Mouse: olhar
- Clique esquerdo: atirar
- Clique direito: mira
- Espaço: pular
- R: recarregar
- Tab: alternar mira
- Esc: pausar
- L: loja (nas telas de menu/pausa)
- 1 a 5: comprar/equipar armas na loja

### Android
- Analógico esquerdo: movimentar
- Arraste no lado direito: olhar
- Botões na direita: tiro, pulo, mira e recarga

## Observações
Esta é uma conversão-base funcional da estrutura e das mecânicas principais. O protótipo original usa Three.js no navegador; LibGDX usa renderização nativa Java, então materiais, modelos, HUD e controles foram recriados em vez de traduzidos linha por linha. A loja de miras, áudio avançado, colisões detalhadas e balanceamento podem ser refinados em uma próxima versão.

## Atualizações recentes
- Textura do terreno em tons de verde mais vivos.
- Colisão das caixas com cobertura da face superior para pouso ao saltar.
- No Android, o botão **MUDAR NOME** abre o teclado nativo apenas para essa ação; o nome fica salvo localmente.
- Lobby com personagem 3D aleatório, cuja escolha fica salva por instalação/dispositivo.

## Atualizações de gameplay (v2.4)
- Lobby com personagem 3D e botões reposicionados em layout tático para mobile.
- HUD FPS com vida, colete de energia, munição, dinheiro e indicador direcional de tiros inimigos.
- Colete de energia absorve parte do dano e recarrega automaticamente após alguns segundos sem receber dano.
- Inimigos equipados com armas e disparos simulados com dispersão maior que a do jogador.
- Botão mobile e tecla V no desktop para alternar a faca; ataque corpo a corpo ao pressionar tiro.
- Casas com abertura de entrada e baús de dinheiro no interior e espalhados aleatoriamente pelo mapa.
- Mira ADS ativada enquanto o botão é mantido pressionado; mira holográfica no rifle, mira de ferro na escopeta e retículos menos brilhantes.
- Grama com verde mais saturado.

## Correções e novidades (v2.5)
- **Desktop:** o módulo `lwjgl3` agora enxerga a pasta de assets (`android/src/main/assets`); antes os modelos 3D não carregavam no PC.
- **Botões:** textos centralizados horizontal e verticalmente (o X era calculado errado) e reduzidos automaticamente se não couberem.
- **Lobby:** cena 3D própria com o personagem do jogador girando (arraste para girar). O painel preto opaco que escondia o modelo foi removido.
- **Contador de kills:** painel no HUD com pulso a cada abate, aviso "+1 KILL +$", hitmarker (vermelho no abate) e kills na tela de morte.
- **Animação de morte:** inimigos tombam, ficam no chão, afundam e somem com fade, com partículas de sangue; não atiram nem são alvo enquanto morrem.
- **Outros bugs:** digitar "L" no nome abria a loja; barra de sensibilidade "pulava" ao arrastar; no PC não era possível olhar com o botão do mouse pressionado; a loja sempre voltava ao menu (agora volta à tela de origem); itens de vida nunca eram dropados (o limite contava os baús de dinheiro); fontes agora escalam com a resolução.
