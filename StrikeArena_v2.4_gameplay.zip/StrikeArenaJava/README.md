# Strike Arena — Java / LibGDX

Port inicial do protótipo HTML enviado para Java com LibGDX, preparado para desktop e Android.

## Requisitos
- JDK 17
- Android Studio (para compilar Android)
- Gradle 8.7+ (ou use o Gradle integrado do Android Studio)

## Executar no PC
Na pasta do projeto:
```bash
gradle :lwjgl3:run
```

## Abrir no Android
1. Abra a pasta do projeto no Android Studio.
2. Aguarde a sincronização do Gradle.
3. Selecione a configuração `android` e execute em um dispositivo/emulador Android.

## Controles
### PC
- WASD: movimentar
- Mouse: olhar
- Clique esquerdo: atirar
- Clique direito: mira
- Espaço: pular
- R: recarregar
- Tab: alternar mira
- Esc: pausar
- L: loja (nas telas de menu/pausa)
- 1 a 5: comprar/equipar armas na loja

### Android
- Analógico esquerdo: movimentar
- Arraste no lado direito: olhar
- Botões na direita: tiro, pulo, mira e recarga

## Observações
Esta é uma conversão-base funcional da estrutura e das mecânicas principais. O protótipo original usa Three.js no navegador; LibGDX usa renderização nativa Java, então materiais, modelos, HUD e controles foram recriados em vez de traduzidos linha por linha. A loja de miras, áudio avançado, colisões detalhadas e balanceamento podem ser refinados em uma próxima versão.

## Atualizações recentes
- Textura do terreno em tons de verde mais vivos.
- Colisão das caixas com cobertura da face superior para pouso ao saltar.
- No Android, o botão **MUDAR NOME** abre o teclado nativo apenas para essa ação; o nome fica salvo localmente.
- Lobby com personagem 3D aleatório, cuja escolha fica salva por instalação/dispositivo.

## Atualizações de gameplay (v2.4)
- Lobby com personagem 3D e botões reposicionados em layout tático para mobile.
- HUD FPS com vida, colete de energia, munição, dinheiro e indicador direcional de tiros inimigos.
- Colete de energia absorve parte do dano e recarrega automaticamente após alguns segundos sem receber dano.
- Inimigos equipados com armas e disparos simulados com dispersão maior que a do jogador.
- Botão mobile e tecla V no desktop para alternar a faca; ataque corpo a corpo ao pressionar tiro.
- Casas com abertura de entrada e baús de dinheiro no interior e espalhados aleatoriamente pelo mapa.
- Mira ADS ativada enquanto o botão é mantido pressionado; mira holográfica no rifle, mira de ferro na escopeta e retículos menos brilhantes.
- Grama com verde mais saturado.
