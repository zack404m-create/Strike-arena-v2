package com.strikearena;

import com.badlogic.gdx.*;
import com.badlogic.gdx.audio.Music;
import com.badlogic.gdx.audio.Sound;
import com.badlogic.gdx.controllers.Controller;
import com.badlogic.gdx.controllers.ControllerMapping;
import com.badlogic.gdx.controllers.Controllers;
import com.badlogic.gdx.graphics.*;
import com.badlogic.gdx.graphics.g2d.*;
import com.badlogic.gdx.graphics.g3d.loader.ObjLoader;
import com.badlogic.gdx.graphics.g3d.attributes.TextureAttribute;
import com.badlogic.gdx.graphics.g3d.*;
import com.badlogic.gdx.graphics.g3d.attributes.ColorAttribute;
import com.badlogic.gdx.graphics.g3d.attributes.BlendingAttribute;
import com.badlogic.gdx.graphics.g3d.environment.DirectionalLight;
import com.badlogic.gdx.graphics.g3d.utils.*;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.math.*;
import com.badlogic.gdx.math.collision.BoundingBox;
import com.badlogic.gdx.utils.*;

import java.util.*;

/**
 * Strike Arena - port Java/LibGDX do protótipo HTML enviado.
 * Código-base jogável para desktop e Android.
 */
public class StrikeArenaGame extends ApplicationAdapter implements InputProcessor {
    private enum Screen { MENU, PLAYING, PAUSED, SHOP, DEAD, LAYOUT }
    private Screen screen = Screen.MENU;

    private PerspectiveCamera camera;
    private ModelBatch modelBatch;
    private ModelBuilder modelBuilder;
    private Environment environment;
    private Model floorModel, wallModel, crateModel, enemyBodyModel, enemyHeadModel, gunModel, pickupModel, houseModel, roofModel, enemyGunModel, knifeBladeModel, knifeHandleModel, moneyChestModel;
    private Texture gunTexture, grassTexture;
    private final Array<BoundingBox> colliders = new Array<>();
    private String playerName = "Soldado";
    private boolean typingName = false;
    private final java.lang.StringBuilder nameBuilder = new java.lang.StringBuilder();
    // Áudio (leve — arquivos opcionais em assets/sounds/)
    private Music ambientMusic;
    private Sound sfxShoot, sfxHit, sfxReload;
    private final Array<ModelInstance> staticWorld = new Array<>();
    private final Array<Model> generatedWorldModels = new Array<>();
    private final Array<Enemy> enemies = new Array<>();
    private final Array<Pickup> pickups = new Array<>();
    private final Vector3 velocity = new Vector3();
    private final Vector3 tmp = new Vector3();
    private final Vector3 forward = new Vector3();
    private final Vector3 right = new Vector3();
    private final Vector3 move = new Vector3();
    private final Vector3 gunOffset = new Vector3(.28f, -.25f, -.55f);

    private BitmapFont font;
    private SpriteBatch hud;
    private ShapeRenderer shapes;
    private final Color red = new Color(1f, .28f, .34f, 1);
    private final Color dark = new Color(.025f, .025f, .05f, 1);

    private final String[] weaponNames = {"Pistola", "SMG", "Rifle", "Shotgun", "Sniper"};
    private final int[] weaponDamage = {28, 17, 36, 52, 90};
    private final float[] weaponRate = {.18f, .07f, .13f, .5f, .9f};
    private final int[] weaponAmmo = {12, 32, 28, 6, 5};
    private final int[] weaponPrice = {0, 400, 700, 900, 1500};
    private final boolean[] weaponOwned = {true, false, false, false, false};
    private final String[] sightNames = {"Padrão", "Red Dot", "Holo", "ACOG"};
    private final int[] sightPrice = {0, 250, 500, 800};
    private final boolean[] sightOwned = {true, false, false, false};

    private int weapon = 0, ammo = 12, sight = 0, kills = 0, money = 0, hp = 100, energyVest = 100;
    private float spawnTimer = 0, lastShot = -10, lastDamage = 0, regenTimer = 0;
    private float yaw = 0, pitch = 0, sens = 1f, volume = .7f;
    private final Vector3 deathPos = new Vector3();
    private float deathYaw = 0f, deathPitch = 0f;
    private boolean canRespawnHere = false;
    private boolean aimAssist = true, ads = false, firing = false, moveForward, moveBack, moveLeft, moveRight;
    private boolean jumpRequested = false, mobile = false, knifeEquipped = false;
    // ===== Controle (gamepad) =====
    private Controller activePad;
    private String padName = "";
    private boolean padConnected = false;
    private float padMoveX, padMoveY, padLookX, padLookY;
    private boolean padFire, padAds, padJump, padReload, padPause, padKnife;
    private boolean padFirePrev, padJumpPrev, padReloadPrev, padPausePrev, padKnifePrev;
    private boolean padUp, padDown, padConfirm, padUpPrev, padDownPrev, padConfirmPrev;
    private float trackStrength = 1.1f; // tracking suave (não substitui mirar)
    private int menuIndex = 0; // navegação de menu pelo controle
    private float menuNavCooldown = 0f;
    private int lookPointer = -1, movePointer = -1, firePointer = -1, aimPointer = -1;
    private float jX, jY, jR, fX, fY, fR, pX, pY, pR, aX, aY, aR, rX, rY, rR, pauseX, pauseY, pauseR, kX, kY, kR;
    private float enemyShotIndicator = 0f, enemyShotAngle = 0f, vestRegenDelay = 0f, vestRegenTimer = 0f;
    private boolean draggingSens = false;
    private float sensMin = 0.3f, sensMax = 2.5f;
    private final GlyphLayout layout = new GlyphLayout();
    private float lookX, lookY, moveX, moveY, touchStartX, touchStartY;
    private float worldTime = 0;
    private final Random random = new Random();
    private static final String[] CHAR_IDS = {"g", "h", "l", "r"};
    private static final float CHAR_SCALE = .62f;
    private final Array<Model> charModels = new Array<>();
    private final Array<Texture> charTextures = new Array<>();
    // Personagem do lobby escolhido uma vez por instalação/dispositivo.
    private int lobbyCharacterIndex = 0;
    private ModelInstance lobbyCharacter;

    // ===== Armas 3D procedurais + miras =====
    private static final int SIGHT_NONE = 0, SIGHT_REDDOT = 1, SIGHT_HOLO = 2, SIGHT_PRISM = 3, SIGHT_IRON = 4;
    private final int[] weaponSight = {SIGHT_REDDOT, SIGHT_HOLO, SIGHT_HOLO, SIGHT_IRON, SIGHT_PRISM};
    private final String[] sightLabel = {"", "Red Dot", "Holográfica", "Prismática", "Mira de Ferro"};
    private final float[] weaponAdsFov = {58f, 55f, 48f, 52f, 20f};
    private final float[][] hipOff = {{.13f,-.12f,-.34f},{.15f,-.13f,-.42f},{.20f,-.17f,-.55f},{.20f,-.17f,-.55f},{.17f,-.15f,-.65f}};
    private final float[][] adsOff = {{0f,-.0445f,-.38f},{0f,-.077f,-.42f},{.07f,-.14f,-.55f},{.07f,-.14f,-.55f},{0f,-.073f,-.65f}};
    private static class GunPart { ModelInstance inst; final Matrix4 local = new Matrix4(); }
    private final Array<Array<GunPart>> weaponParts = new Array<>();
    private final Array<Model> gunModels = new Array<>();
    private PerspectiveCamera viewCam;
    private Environment viewEnv;
    private Texture scopeTex;
    private float adsT = 0, kick = 0;
    private final Matrix4 viewBase = new Matrix4();

    // ===== Efeitos: tracantes, capsulas, labareda, recarga =====
    private static class Tracer { final Vector3 pos = new Vector3(), dir = new Vector3(); float total, traveled; boolean visible; ModelInstance inst; }
    private static class Casing { final Vector3 pos = new Vector3(), vel = new Vector3(); float rx, ry, sx, sy, life, scale = 1f; boolean landed; ModelInstance inst; }
    private final Array<Tracer> tracers = new Array<>();
    private final Array<Casing> casings = new Array<>();
    private Model tracerModel, casingModel;
    private ModelInstance knifeBladeInstance, knifeHandleInstance;
    private final Array<GunPart> flashParts = new Array<>();
    private final Matrix4 flashBase = new Matrix4();
    private final Vector3 tmp2 = new Vector3();
    private float flashT = 0f, flashScale = 1f, flashRot = 0f;
    private final float[][] muzzleOff = {{0f,.003f,-.13f},{0f,.004f,-.45f},{0f,.004f,-.53f},{0f,.012f,-.67f},{0f,.004f,-.78f}};
    private final float[] casingScale = {1f, .9f, 1.2f, 1.6f, 2f};
    private boolean reloading = false;
    private float reloadTimer = 0f;
    private final float[] weaponReload = {1.2f, 1.7f, 2.1f, 2.6f, 2.8f};

    // ===== Personalizar HUD =====
    private static final float HUD_MIN = .6f, HUD_MAX = 1.5f;
    private float hudScale = 1f;
    private boolean hudCustom = false, draggingHudScale = false;
    private final float[] ctlX = new float[6], ctlY = new float[6];
    private int layoutDrag = -1;
    private float dragDX, dragDY;
    private float lsX0, lsX1, lsY, lbW, lbH, lbY, lbRX, lbDX;
    private Preferences prefs;
    private static final Color C_DARK = new Color(.12f,.13f,.15f,1), C_MID = new Color(.23f,.24f,.28f,1),
        C_LIGHT = new Color(.45f,.47f,.53f,1), C_BLACK = new Color(.05f,.05f,.06f,1),
        C_OLIVE = new Color(.22f,.27f,.19f,1), C_ORANGE = new Color(1f,.55f,.10f,1), C_GLASS = new Color(.45f,.75f,1f,1);

    private static class Enemy {
        ModelInstance body, head, weapon;
        boolean skinned;
        Vector3 position = new Vector3();
        float hp = 100, speed, attackTimer, shotTimer;
        float facing = 0f;                 // graus (rotação em Y)
        boolean dying = false;             // true = animação de morte em andamento
        float deathTime = 0f;
        final Vector3 fallDir = new Vector3();
    }
    // Partículas de impacto/morte (cubinhos que voam e somem)
    private static class Particle {
        final Vector3 pos = new Vector3(), vel = new Vector3();
        float life, maxLife, size;
        ModelInstance inst;
    }
    private static final float DEATH_FALL = .55f, DEATH_LIE = .9f, DEATH_FADE = .75f;
    private static final float DEATH_TOTAL = DEATH_FALL + DEATH_LIE + DEATH_FADE;
    private final Array<Particle> particles = new Array<>();
    private Model particleModel;
    private final Matrix4 enemyBase = new Matrix4();
    private final Matrix4 enemyTmp = new Matrix4();
    // Contador de kills / feedback
    private float killPulse = 0f, killFeedT = 0f, hitMarkerT = 0f;
    private boolean hitMarkerKill = false;
    private int lastKillReward = 0;
    // Lobby 3D
    private PerspectiveCamera lobbyCam;
    private Environment lobbyEnv;
    private float lobbyYaw = 25f;
    private boolean draggingLobby = false;
    private float lobbyDragX = 0f;
    private Screen shopReturn = Screen.MENU;
    private static class Pickup {
        ModelInstance model;
        boolean cash = false;
        int cashValue = 0;
        Vector3 position = new Vector3();
        float phase;
    }

    @Override public void create() {
        mobile = Gdx.app.getType() == Application.ApplicationType.Android;
        modelBatch = new ModelBatch();
        modelBuilder = new ModelBuilder();
        hud = new SpriteBatch();
        shapes = new ShapeRenderer();
        font = new BitmapFont();
        font.getData().setScale(1.15f);
        camera = new PerspectiveCamera(75, Gdx.graphics.getWidth(), Gdx.graphics.getHeight());
        camera.position.set(0, 1.7f, 0);
        camera.lookAt(0, 1.7f, -1);
        camera.near = .1f; camera.far = 200; camera.update();
        environment = new Environment();
        environment.set(new ColorAttribute(ColorAttribute.AmbientLight, .48f, .48f, .58f, 1));
        environment.add(new DirectionalLight().set(1f, .88f, .72f, -1, -2, -1));
        loadHudPrefs();
        buildWorld();
        loadCharacters();
        if (charModels.size > 0) {
            if (lobbyCharacterIndex < 0 || lobbyCharacterIndex >= charModels.size) {
                lobbyCharacterIndex = random.nextInt(charModels.size);
                if (prefs != null) prefs.putInteger("lobbyCharacterIndex", lobbyCharacterIndex).flush();
            }
            lobbyCharacter = new ModelInstance(charModels.get(lobbyCharacterIndex));
        }
        buildWeaponModels();
        knifeBladeInstance = new ModelInstance(knifeBladeModel);
        knifeHandleInstance = new ModelInstance(knifeHandleModel);
        buildEffects();
        buildLobbyScene();
        // Áudio opcional (coloque arquivos em assets/sounds/ se quiser)
        try {
            if (Gdx.files.internal("sounds/ambient.mp3").exists()) {
                ambientMusic = Gdx.audio.newMusic(Gdx.files.internal("sounds/ambient.mp3"));
                ambientMusic.setLooping(true);
                ambientMusic.setVolume(0.35f * volume);
                ambientMusic.play();
            }
            if (Gdx.files.internal("sounds/shoot.wav").exists())
                sfxShoot = Gdx.audio.newSound(Gdx.files.internal("sounds/shoot.wav"));
            if (Gdx.files.internal("sounds/hit.wav").exists())
                sfxHit = Gdx.audio.newSound(Gdx.files.internal("sounds/hit.wav"));
            if (Gdx.files.internal("sounds/reload.wav").exists())
                sfxReload = Gdx.audio.newSound(Gdx.files.internal("sounds/reload.wav"));
        } catch (Exception ignored) {}
        Gdx.input.setInputProcessor(this);
        Gdx.input.setCatchKey(Input.Keys.BACK, true);
        initControllers();
    }

    private void initControllers() {
        try {
            refreshController();
            Controllers.addListener(new com.badlogic.gdx.controllers.ControllerAdapter() {
                @Override public void connected(Controller controller) {
                    activePad = controller;
                    padConnected = true;
                    padName = controller.getName();
                    Gdx.app.log("Pad", "Conectado: " + padName);
                }
                @Override public void disconnected(Controller controller) {
                    if (activePad == controller) {
                        activePad = null;
                        padConnected = false;
                        padName = "";
                        resetPadState();
                    }
                    refreshController();
                    Gdx.app.log("Pad", "Desconectado");
                }
            });
        } catch (Exception e) {
            Gdx.app.error("Pad", "Falha ao iniciar controles", e);
        }
    }

    private void refreshController() {
        activePad = null;
        padConnected = false;
        padName = "";
        if (Controllers.getControllers().size > 0) {
            activePad = Controllers.getControllers().first();
            padConnected = true;
            padName = activePad.getName();
        }
    }

    private void resetPadState() {
        padMoveX = padMoveY = padLookX = padLookY = 0;
        padFire = padAds = padJump = padReload = padPause = padKnife = false;
        padFirePrev = padJumpPrev = padReloadPrev = padPausePrev = padKnifePrev = false;
        padUp = padDown = padConfirm = false;
        padUpPrev = padDownPrev = padConfirmPrev = false;
    }

    private void pollController(float dt) {
        if (activePad == null || !activePad.isConnected()) {
            refreshController();
            if (activePad == null) {
                resetPadState();
                return;
            }
        }
        ControllerMapping map = activePad.getMapping();
        if (map == null) return;

        float dead = 0.22f;
        // Analógico esquerdo = movimento (NÃO usa eixos do stick direito)
        float lx = axisSafe(activePad, map.axisLeftX);
        float ly = axisSafe(activePad, map.axisLeftY);
        padMoveX = Math.abs(lx) > dead ? lx : 0f;
        padMoveY = Math.abs(ly) > dead ? ly : 0f;

        // Analógico direito = olhar APENAS (nunca ativa ADS)
        float rx = axisSafe(activePad, map.axisRightX);
        float ry = axisSafe(activePad, map.axisRightY);
        padLookX = Math.abs(rx) > dead ? rx : 0f;
        padLookY = Math.abs(ry) > dead ? ry : 0f;

        // Edge detection
        padFirePrev = padFire;
        padJumpPrev = padJump;
        padReloadPrev = padReload;
        padPausePrev = padPause;
        padKnifePrev = padKnife;
        padUpPrev = padUp;
        padDownPrev = padDown;
        padConfirmPrev = padConfirm;

        // ===== TIRO: só RT/R2 ou RB/R1 — NUNCA eixos do stick =====
        float rt = 0f;
        if (map.buttonR2 >= 0 && activePad.getButton(map.buttonR2)) rt = 1f;
        // Alguns pads reportam gatilho como eixo dedicado (não stick)
        // Só aceita se o eixo NÃO for left/right stick
        int axLX = map.axisLeftX, axLY = map.axisLeftY, axRX = map.axisRightX, axRY = map.axisRightY;
        for (int ai = 0; ai < 8; ai++) {
            if (ai == axLX || ai == axLY || ai == axRX || ai == axRY) continue;
            float a = axisSafe(activePad, ai);
            // gatilhos costumam ir de -1..1 ou 0..1
            float v = a > 0.3f ? a : (a < -0.3f ? -a : 0f);
            if (v > rt) rt = v;
        }
        padFire = rt > 0.35f || (map.buttonR1 >= 0 && activePad.getButton(map.buttonR1));

        // ===== MIRA (ADS): só LT/L2 ou LB/L1 — NUNCA stick direito =====
        float lt = 0f;
        if (map.buttonL2 >= 0 && activePad.getButton(map.buttonL2)) lt = 1f;
        // LB também pode segurar mira
        boolean lb = map.buttonL1 >= 0 && activePad.getButton(map.buttonL1);
        padAds = lt > 0.35f || lb;
        // IMPORTANTE: não setar ads a partir de nenhum eixo de stick

        padJump = map.buttonA >= 0 && activePad.getButton(map.buttonA);
        padReload = map.buttonX >= 0 && activePad.getButton(map.buttonX);
        padPause = (map.buttonStart >= 0 && activePad.getButton(map.buttonStart))
                || (map.buttonBack >= 0 && activePad.getButton(map.buttonBack));
        padKnife = map.buttonY >= 0 && activePad.getButton(map.buttonY);

        // D-pad / stick esquerdo pra menu
        padUp = (map.buttonDpadUp >= 0 && activePad.getButton(map.buttonDpadUp)) || padMoveY < -0.55f;
        padDown = (map.buttonDpadDown >= 0 && activePad.getButton(map.buttonDpadDown)) || padMoveY > 0.55f;
        padConfirm = padJump; // A confirma

        // ===== JOGO =====
        if (screen == Screen.PLAYING) {
            if (padJump && !padJumpPrev) jumpRequested = true;
            if (padReload && !padReloadPrev) {
                try { startReload(); } catch (Exception ignored) {}
            }
            if (padKnife && !padKnifePrev) knifeEquipped = !knifeEquipped;
            if (padFire) fire();
            // ADS só pelo gatilho/LB — soltar solta a mira
            if (padAds) ads = true;
            else if (!Gdx.input.isButtonPressed(Input.Buttons.RIGHT)) ads = false;
        }

        // Pause / atalhos globais
        if (padPause && !padPausePrev) {
            if (screen == Screen.PLAYING) { screen = Screen.PAUSED; unlockMouse(); menuIndex = 0; }
            else if (screen == Screen.PAUSED) { screen = Screen.PLAYING; lockMouse(); }
            else if (screen == Screen.DEAD) { respawnHere(); }
            else if (screen == Screen.MENU) { startGame(); }
            else if (screen == Screen.SHOP) { screen = Screen.MENU; }
        }

        // Navegação de menus com controle
        handlePadMenuNav(dt);
    }

    private void handlePadMenuNav(float dt) {
        if (screen == Screen.PLAYING || screen == Screen.LAYOUT) return;
        menuNavCooldown = Math.max(0f, menuNavCooldown - dt);

        int maxIdx = 0;
        if (screen == Screen.MENU) maxIdx = 3;       // JOGAR, LOJA, NOME, (extra)
        else if (screen == Screen.DEAD) maxIdx = 3;  // Respawn, Jogar, Loja, Menu
        else if (screen == Screen.PAUSED) maxIdx = 3;
        else if (screen == Screen.SHOP) maxIdx = weaponNames.length; // armas + voltar

        if (menuNavCooldown <= 0f) {
            if (padDown && !padDownPrev) {
                menuIndex = (menuIndex + 1) % (maxIdx + 1);
                menuNavCooldown = 0.22f;
            } else if (padUp && !padUpPrev) {
                menuIndex = (menuIndex - 1 + maxIdx + 1) % (maxIdx + 1);
                menuNavCooldown = 0.22f;
            }
        }

        if (padConfirm && !padConfirmPrev) {
            activateMenuIndex();
        }
    }

    private void activateMenuIndex() {
        if (screen == Screen.MENU) {
            if (menuIndex == 0) startGame();
            else if (menuIndex == 1) openShop();
            else if (menuIndex == 2) { /* mudar nome — no PC ignora teclado nativo */ }
        } else if (screen == Screen.DEAD) {
            if (menuIndex == 0) respawnHere();
            else if (menuIndex == 1) startGame();
            else if (menuIndex == 2) openShop();
            else if (menuIndex == 3) screen = Screen.MENU;
        } else if (screen == Screen.PAUSED) {
            if (menuIndex == 0) { screen = Screen.PLAYING; lockMouse(); }
            else if (menuIndex == 1) openShop();
            else if (menuIndex == 2) { /* personalizar HUD */ }
            else if (menuIndex == 3) screen = Screen.MENU;
        } else if (screen == Screen.SHOP) {
            if (menuIndex < weaponNames.length) buyWeapon(menuIndex);
            else screen = Screen.MENU;
        }
    }

    private float axisSafe(Controller c, int axis) {
        if (axis < 0) return 0f;
        try { return c.getAxis(axis); } catch (Exception e) { return 0f; }
    }

    /** Tracking: puxa a mira suavemente pro inimigo mais próximo do centro. */
    private void applyTargetTracking(float dt) {
        if (enemies.size == 0) return;
        Enemy best = null;
        // Só ajuda se o inimigo já estiver bem perto da mira (~18°)
        float bestScore = 0.95f;
        Vector3 dir = camera.direction;
        for (int i = 0; i < enemies.size; i++) {
            Enemy e = enemies.get(i);
            if (e.dying || e.hp <= 0) continue;
            tmp.set(e.position.x, e.position.y + 1.15f, e.position.z).sub(camera.position);
            float dist = tmp.len();
            if (dist < 0.5f || dist > 80f) continue;
            tmp.scl(1f / dist);
            float d = dir.dot(tmp);
            if (d > bestScore) {
                bestScore = d;
                best = e;
            }
        }
        if (best == null) return;

        tmp.set(best.position.x, best.position.y + 1.15f, best.position.z).sub(camera.position).nor();
        float targetYaw = MathUtils.atan2(-tmp.x, -tmp.z);
        float flat = (float) Math.sqrt(tmp.x * tmp.x + tmp.z * tmp.z);
        float targetPitch = MathUtils.atan2(tmp.y, flat);

        // Pull moderado — ajuda a finalizar a mira, não puxa de longe
        float boost = (ads || padAds) ? 2.2f : (padFire || firing ? 1.5f : 0.9f);
        float pull = Math.min(0.85f, trackStrength * boost * dt);

        float dyaw = targetYaw - yaw;
        while (dyaw > MathUtils.PI) dyaw -= MathUtils.PI2;
        while (dyaw < -MathUtils.PI) dyaw += MathUtils.PI2;
        yaw += dyaw * pull;
        pitch += (targetPitch - pitch) * pull;
        pitch = MathUtils.clamp(pitch, -1.35f, 1.35f);
    }

    private Material solid(Color c) { return new Material(ColorAttribute.createDiffuse(c)); }
    private void gpAdd(Array<GunPart> l, Model m, float x, float y, float z, float rotX, boolean cyl) {
        gunModels.add(m);
        GunPart p = new GunPart();
        p.inst = new ModelInstance(m);
        p.local.setToTranslation(x, y, z);
        if (cyl) p.local.rotate(Vector3.X, 90f);
        if (rotX != 0f) p.local.rotate(Vector3.X, rotX);
        l.add(p);
    }
    private void gpBox(Array<GunPart> l, float w, float h, float d, float x, float y, float z, float rotX, Color c) {
        gpAdd(l, modelBuilder.createBox(w, h, d, solid(c),
            VertexAttributes.Usage.Position | VertexAttributes.Usage.Normal), x, y, z, rotX, false);
    }
    private void gpCyl(Array<GunPart> l, float dia, float len, float x, float y, float z, Color c) {
        gpAdd(l, modelBuilder.createCylinder(dia, len, dia, 14, solid(c),
            VertexAttributes.Usage.Position | VertexAttributes.Usage.Normal), x, y, z, 0f, true);
    }
    private void gpGlass(Array<GunPart> l, float w, float h, float d, float x, float y, float z, float alpha) {
        Material mat = new Material(ColorAttribute.createDiffuse(C_GLASS), new BlendingAttribute(true, alpha));
        gpAdd(l, modelBuilder.createBox(w, h, d, mat,
            VertexAttributes.Usage.Position | VertexAttributes.Usage.Normal), x, y, z, 0f, false);
    }

    private void buildWeaponModels() {
        for (int i = 0; i < weaponNames.length; i++) weaponParts.add(new Array<GunPart>());
        buildPistol(weaponParts.get(0));
        buildSmg(weaponParts.get(1));
        buildRifle(weaponParts.get(2));
        buildShotgun(weaponParts.get(3));
        buildSniper(weaponParts.get(4));

        viewCam = new PerspectiveCamera(60, Gdx.graphics.getWidth(), Gdx.graphics.getHeight());
        viewCam.position.set(0, 0, 0);
        viewCam.lookAt(0, 0, -1);
        viewCam.up.set(0, 1, 0);
        viewCam.near = .03f; viewCam.far = 4f; viewCam.update();
        viewEnv = new Environment();
        viewEnv.set(new ColorAttribute(ColorAttribute.AmbientLight, .62f, .62f, .68f, 1));
        viewEnv.add(new DirectionalLight().set(1f, .96f, .9f, -.4f, -.8f, -.6f));

        // Mascara circular da luneta (preto fora, transparente no meio)
        int n = 512;
        Pixmap pm = new Pixmap(n, n, Pixmap.Format.RGBA8888);
        pm.setBlending(Pixmap.Blending.None);
        for (int py = 0; py < n; py++) {
            for (int px = 0; px < n; px++) {
                float dx = (px - n / 2f) / (n / 2f), dy = (py - n / 2f) / (n / 2f);
                float d = (float) Math.sqrt(dx * dx + dy * dy);
                float a = d < .88f ? 0f : (d > .91f ? 1f : (d - .88f) / .03f);
                pm.setColor(0f, 0f, 0f, a);
                pm.drawPixel(px, py);
            }
        }
        scopeTex = new Texture(pm);
        scopeTex.setFilter(Texture.TextureFilter.Linear, Texture.TextureFilter.Linear);
        pm.dispose();
    }

    private void buildPistol(Array<GunPart> l) {
        gpBox(l, .034f, .042f, .19f, 0, 0, 0, 0, C_DARK);
        gpCyl(l, .014f, .03f, 0, .003f, -.108f, C_LIGHT);
        gpBox(l, .030f, .024f, .17f, 0, -.033f, .005f, 0, C_MID);
        gpBox(l, .032f, .095f, .046f, 0, -.090f, .062f, -12f, C_BLACK);
        gpBox(l, .008f, .004f, .05f, 0, -.060f, -.03f, 0, C_MID);
        gpBox(l, .006f, .022f, .008f, 0, -.052f, -.004f, 10f, C_LIGHT);
        gpBox(l, .012f, .008f, .012f, 0, .0245f, -.085f, 0, C_BLACK);
        // Red dot
        gpBox(l, .034f, .006f, .052f, 0, .024f, .040f, 0, C_BLACK);
        gpBox(l, .004f, .034f, .052f, -.0145f, .044f, .040f, 0, C_BLACK);
        gpBox(l, .004f, .034f, .052f, .0145f, .044f, .040f, 0, C_BLACK);
        gpBox(l, .033f, .006f, .052f, 0, .064f, .040f, 0, C_BLACK);
        gpBox(l, .010f, .008f, .010f, 0, .034f, .020f, 0, C_DARK);
        gpGlass(l, .025f, .026f, .002f, 0, .0445f, .052f, .22f);
    }

    private void buildSmg(Array<GunPart> l) {
        gpBox(l, .046f, .062f, .22f, 0, 0, .02f, 0, C_DARK);
        gpBox(l, .042f, .048f, .15f, 0, -.004f, -.165f, 0, C_MID);
        gpCyl(l, .016f, .12f, 0, .004f, -.30f, C_LIGHT);
        gpCyl(l, .032f, .14f, 0, .004f, -.35f, C_BLACK);
        gpBox(l, .030f, .050f, .14f, 0, -.012f, .215f, 0, C_BLACK);
        gpBox(l, .034f, .070f, .02f, 0, -.012f, .29f, 0, C_BLACK);
        gpBox(l, .034f, .10f, .05f, 0, -.085f, .06f, -14f, C_BLACK);
        gpBox(l, .028f, .12f, .05f, 0, -.100f, -.045f, 6f, C_DARK);
        gpBox(l, .030f, .065f, .036f, 0, -.062f, -.16f, 0, C_BLACK);
        gpBox(l, .020f, .008f, .22f, 0, .035f, .02f, 0, C_LIGHT);
        // Holografica
        gpBox(l, .044f, .012f, .075f, 0, .045f, .01f, 0, C_BLACK);
        gpBox(l, .006f, .050f, .075f, -.029f, .076f, .01f, 0, C_BLACK);
        gpBox(l, .006f, .050f, .075f, .029f, .076f, .01f, 0, C_BLACK);
        gpBox(l, .064f, .008f, .075f, 0, .105f, .01f, 0, C_BLACK);
        gpBox(l, .050f, .018f, .022f, 0, .062f, -.035f, 0, C_DARK);
        gpGlass(l, .052f, .046f, .002f, 0, .077f, .040f, .20f);
    }

    private void buildRifle(Array<GunPart> l) {
        gpBox(l, .05f, .06f, .30f, 0, 0, .02f, 0, C_DARK);
        gpCyl(l, .02f, .35f, 0, .004f, -.325f, C_LIGHT);
        gpBox(l, .05f, .05f, .20f, 0, -.004f, -.20f, 0, C_MID);
        gpBox(l, .04f, .07f, .22f, 0, -.02f, .27f, 0, C_OLIVE);
        gpBox(l, .034f, .095f, .045f, 0, -.08f, .08f, -14f, C_BLACK);
        gpBox(l, .028f, .11f, .05f, 0, -.095f, -.02f, 8f, C_DARK);
        gpBox(l, .006f, .03f, .006f, 0, .045f, -.28f, 0, C_BLACK);
        gpBox(l, .02f, .02f, .012f, 0, .04f, .12f, 0, C_BLACK);
        // Janela holográfica compacta do rifle.
        gpBox(l, .085f, .012f, .095f, 0, .072f, -.015f, 0, C_BLACK);
        gpBox(l, .008f, .060f, .095f, -.039f, .102f, -.015f, 0, C_BLACK);
        gpBox(l, .008f, .060f, .095f, .039f, .102f, -.015f, 0, C_BLACK);
        gpGlass(l, .066f, .044f, .003f, 0, .103f, .025f, .16f);
    }

    private void buildShotgun(Array<GunPart> l) {
        gpBox(l, .05f, .06f, .22f, 0, 0, .04f, 0, C_DARK);
        gpCyl(l, .03f, .50f, 0, .012f, -.38f, C_MID);
        gpCyl(l, .026f, .42f, 0, -.028f, -.34f, C_LIGHT);
        gpBox(l, .05f, .04f, .12f, 0, -.03f, -.30f, 0, C_OLIVE);
        gpBox(l, .04f, .075f, .26f, 0, -.02f, .24f, 0, C_OLIVE);
        gpBox(l, .034f, .09f, .042f, 0, -.07f, .09f, -14f, C_BLACK);
        gpBox(l, .008f, .012f, .008f, 0, .03f, -.62f, 0, C_LIGHT);
        // Massa e alça de mira de ferro da escopeta.
        gpBox(l, .055f, .010f, .018f, 0, .060f, -.53f, 0, C_BLACK);
        gpBox(l, .010f, .038f, .014f, -.024f, .080f, .12f, 0, C_BLACK);
        gpBox(l, .010f, .038f, .014f, .024f, .080f, .12f, 0, C_BLACK);
        gpBox(l, .008f, .022f, .012f, 0, .082f, -.53f, 0, C_LIGHT);
    }

    private void buildSniper(Array<GunPart> l) {
        gpBox(l, .044f, .054f, .28f, 0, 0, .04f, 0, C_DARK);
        gpCyl(l, .022f, .55f, 0, .004f, -.40f, C_LIGHT);
        gpCyl(l, .030f, .07f, 0, .004f, -.70f, C_BLACK);
        gpBox(l, .046f, .050f, .24f, 0, -.008f, -.17f, 0, C_OLIVE);
        gpBox(l, .040f, .070f, .30f, 0, -.022f, .36f, 0, C_OLIVE);
        gpBox(l, .034f, .028f, .15f, 0, .034f, .37f, 0, C_OLIVE);
        gpBox(l, .042f, .092f, .022f, 0, -.024f, .52f, 0, C_BLACK);
        gpBox(l, .034f, .095f, .042f, 0, -.075f, .17f, -16f, C_BLACK);
        gpBox(l, .028f, .070f, .05f, 0, -.060f, .02f, 0, C_DARK);
        gpBox(l, .050f, .010f, .010f, .035f, .012f, .08f, 0, C_LIGHT);
        gpBox(l, .018f, .018f, .018f, .064f, .012f, .08f, 0, C_BLACK);
        // Luneta prismatica
        gpBox(l, .020f, .026f, .040f, 0, .037f, -.020f, 0, C_BLACK);
        gpBox(l, .020f, .026f, .040f, 0, .037f, .090f, 0, C_BLACK);
        gpCyl(l, .034f, .19f, 0, .073f, .035f, C_DARK);
        gpCyl(l, .044f, .04f, 0, .073f, -.085f, C_BLACK);
        gpCyl(l, .040f, .03f, 0, .073f, .14f, C_BLACK);
        gpBox(l, .006f, .006f, .14f, 0, .098f, 0, 0, C_ORANGE);
    }

    private void renderViewModel() {
        if (weapon == 4 && adsT > .8f) return;   // o overlay da luneta substitui o modelo
        Gdx.gl.glClear(GL20.GL_DEPTH_BUFFER_BIT);
        viewCam.viewportWidth = Gdx.graphics.getWidth();
        viewCam.viewportHeight = Gdx.graphics.getHeight();
        viewCam.update();
        float[] hp = hipOff[weapon], ap = adsOff[weapon];
        float ox = MathUtils.lerp(hp[0], ap[0], adsT);
        float oy = MathUtils.lerp(hp[1], ap[1], adsT);
        float oz = MathUtils.lerp(hp[2], ap[2], adsT) + kick * .03f;
        float rl = reloading ? MathUtils.sin(MathUtils.PI * MathUtils.clamp(reloadTimer / weaponReload[weapon], 0f, 1f)) : 0f;
        viewBase.setToTranslation(ox, oy - rl * .12f, oz);
        viewBase.rotate(Vector3.X, kick * 2.5f - rl * 30f);
        viewBase.rotate(Vector3.Z, rl * 14f);
        modelBatch.begin(viewCam);
        if (knifeEquipped) {
            Matrix4 knifeBase = new Matrix4(viewBase).translate(.04f, -.015f, -.20f).rotate(Vector3.X, -12f);
            knifeBladeInstance.transform.set(knifeBase).translate(0, 0, -.30f);
            knifeHandleInstance.transform.set(knifeBase).translate(0, 0, .05f);
            modelBatch.render(knifeBladeInstance, viewEnv); modelBatch.render(knifeHandleInstance, viewEnv);
        } else {
            for (GunPart p : weaponParts.get(weapon)) {
                p.inst.transform.set(viewBase).mul(p.local);
                modelBatch.render(p.inst, viewEnv);
            }
        }
        if (flashT > 0f) {
            float[] mo = muzzleOff[weapon];
            float fs = flashScale * (.6f + .4f * (flashT / .06f));
            flashBase.set(viewBase).translate(mo[0], mo[1], mo[2]).rotate(Vector3.Z, flashRot).scale(fs, fs, fs);
            for (GunPart p : flashParts) {
                p.inst.transform.set(flashBase).mul(p.local);
                modelBatch.render(p.inst, viewEnv);
            }
        }
        modelBatch.end();
    }

    private void ring(float cx, float cy, float r, float th, int seg) {
        float px = cx + r, py = cy;
        for (int i = 1; i <= seg; i++) {
            float ang = MathUtils.PI2 * i / seg;
            float x = cx + MathUtils.cos(ang) * r, y = cy + MathUtils.sin(ang) * r;
            shapes.rectLine(px, py, x, y, th);
            px = x; py = y;
        }
    }

    private void drawSight(float w, float h) {
        int type = weaponSight[weapon];
        float a = MathUtils.clamp((adsT - .3f) / .7f, 0f, 1f);
        float cx = w / 2f, cy = h / 2f;
        Gdx.gl.glEnable(GL20.GL_BLEND);
        Gdx.gl.glBlendFunc(GL20.GL_SRC_ALPHA, GL20.GL_ONE_MINUS_SRC_ALPHA);
        if (type == SIGHT_PRISM) {
            float r = h * .52f;
            if (cx - r > 0) {
                shapes.begin(ShapeRenderer.ShapeType.Filled);
                shapes.setColor(0, 0, 0, a);
                shapes.rect(0, 0, cx - r, h);
                shapes.rect(cx + r, 0, w - cx - r, h);
                shapes.end();
            }
            hud.begin();
            hud.setColor(1, 1, 1, a);
            hud.draw(scopeTex, cx - r, cy - r, 2 * r, 2 * r);
            hud.setColor(Color.WHITE);
            hud.end();
        }
        shapes.begin(ShapeRenderer.ShapeType.Filled);
        if (type == SIGHT_REDDOT) {
            shapes.setColor(1f, .10f, .10f, .10f * a); shapes.circle(cx, cy, h * .010f);
            shapes.setColor(.95f, .16f, .16f, .58f * a); shapes.circle(cx, cy, h * .0038f);
        } else if (type == SIGHT_HOLO) {
            float R = h * .035f, th = h * .003f, tk = h * .012f;
            shapes.setColor(.35f, .88f, .48f, .62f * a);
            ring(cx, cy, R, th, 48);
            shapes.circle(cx, cy, h * .0045f);
            shapes.rectLine(cx, cy + R, cx, cy + R + tk, th);
            shapes.rectLine(cx, cy - R, cx, cy - R - tk, th);
            shapes.rectLine(cx - R, cy, cx - R - tk, cy, th);
            shapes.rectLine(cx + R, cy, cx + R + tk, cy, th);
        } else if (type == SIGHT_IRON) {
            float th = h * .003f, R = h * .040f;
            shapes.setColor(.90f, .92f, .88f, .58f * a);
            shapes.rectLine(cx - R, cy + R, cx - R*.35f, cy + R*.15f, th);
            shapes.rectLine(cx + R, cy + R, cx + R*.35f, cy + R*.15f, th);
            shapes.rectLine(cx - R, cy + R, cx - R, cy - R*.45f, th);
            shapes.rectLine(cx + R, cy + R, cx + R, cy - R*.45f, th);
            shapes.circle(cx, cy - R*.12f, h*.003f);
        } else if (type == SIGHT_PRISM) {
            float th = h * .0022f, gap = h * .012f, ext = h * .45f;
            shapes.setColor(0, 0, 0, .9f * a);
            shapes.rectLine(cx - ext, cy, cx - gap, cy, th);
            shapes.rectLine(cx + gap, cy, cx + ext, cy, th);
            shapes.rectLine(cx, cy + gap, cx, cy + ext, th);
            shapes.rectLine(cx, cy - gap, cx, cy - ext, th);
            for (int i = 1; i <= 3; i++) {
                float yy = cy - h * .075f * i, len = h * (.022f - .003f * i);
                shapes.rectLine(cx - len, yy, cx + len, yy, th * 1.4f);
            }
            shapes.setColor(1f, .12f, .10f, a);
            shapes.rectLine(cx, cy, cx - h * .022f, cy - h * .032f, th * 2.2f);
            shapes.rectLine(cx, cy, cx + h * .022f, cy - h * .032f, th * 2.2f);
            shapes.circle(cx, cy, h * .0028f);
        }
        shapes.end();
        Gdx.gl.glDisable(GL20.GL_BLEND);
    }

    private void buildEffects() {
        long u = VertexAttributes.Usage.Position | VertexAttributes.Usage.Normal;
        Material tm = new Material(ColorAttribute.createDiffuse(1f, .88f, .45f, 1f),
            ColorAttribute.createEmissive(1f, .85f, .4f, 1f),
            new BlendingAttribute(GL20.GL_SRC_ALPHA, GL20.GL_ONE, .95f));
        tracerModel = modelBuilder.createBox(.035f, .035f, 2.5f, tm, u);
        gunModels.add(tracerModel);
        casingModel = modelBuilder.createCylinder(.011f, .035f, .011f, 8,
            new Material(ColorAttribute.createDiffuse(.86f, .66f, .22f, 1f)), u);
        gunModels.add(casingModel);
        Material fm = new Material(ColorAttribute.createDiffuse(1f, .9f, .5f, 1f),
            ColorAttribute.createEmissive(1f, .78f, .25f, 1f),
            new BlendingAttribute(GL20.GL_SRC_ALPHA, GL20.GL_ONE, .9f));
        gpAdd(flashParts, modelBuilder.createSphere(.05f, .05f, .05f, 8, 8, fm, u), 0, 0, 0, 0, false);
        gpAdd(flashParts, modelBuilder.createBox(.16f, .008f, .008f, fm, u), 0, 0, 0, 0, false);
        gpAdd(flashParts, modelBuilder.createBox(.008f, .16f, .008f, fm, u), 0, 0, 0, 0, false);
        gpAdd(flashParts, modelBuilder.createBox(.008f, .008f, .14f, fm, u), 0, 0, -.05f, 0, false);
        particleModel = modelBuilder.createBox(.08f, .08f, .08f,
            new Material(ColorAttribute.createDiffuse(.78f, .06f, .07f, 1f),
                         ColorAttribute.createEmissive(.25f, .0f, .0f, 1f)), u);
        gunModels.add(particleModel);
    }

    // ===== Lobby 3D: câmera, luzes e cena própria do personagem =====
    private void buildLobbyScene() {
        lobbyCam = new PerspectiveCamera(34f, Gdx.graphics.getWidth(), Gdx.graphics.getHeight());
        lobbyCam.near = .1f; lobbyCam.far = 40f;
        lobbyEnv = new Environment();
        lobbyEnv.set(new ColorAttribute(ColorAttribute.AmbientLight, .50f, .53f, .64f, 1f));
        lobbyEnv.add(new DirectionalLight().set(1f, .95f, .85f, -.45f, -.55f, -1f));   // luz principal
        lobbyEnv.add(new DirectionalLight().set(.22f, .42f, .95f, .85f, -.15f, .55f)); // contraluz azulada
    }

    private boolean lobbyScene() {
        return screen == Screen.MENU || (screen == Screen.SHOP && shopReturn == Screen.MENU);
    }

    private void renderLobby(float dt) {
        float w = Gdx.graphics.getWidth(), h = Gdx.graphics.getHeight();
        Gdx.gl.glClearColor(.03f, .04f, .08f, 1f);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT | GL20.GL_DEPTH_BUFFER_BIT);
        lobbyCam.viewportWidth = w; lobbyCam.viewportHeight = h;
        lobbyCam.position.set(0f, 1.55f, 5.9f);
        lobbyCam.up.set(0f, 1f, 0f);
        lobbyCam.lookAt(0f, 1.30f, 0f);
        lobbyCam.update();

        // Fundo em degradê + faixas diagonais + "palco" sob o personagem (2D)
        Vector3 feet = lobbyCam.project(new Vector3(0f, 0f, 0f));
        Vector3 edge = lobbyCam.project(new Vector3(1.5f, 0f, 0f));
        float rx = Math.abs(edge.x - feet.x), ry = rx * .26f;
        Gdx.gl.glEnable(GL20.GL_BLEND);
        Gdx.gl.glBlendFunc(GL20.GL_SRC_ALPHA, GL20.GL_ONE_MINUS_SRC_ALPHA);
        shapes.begin(ShapeRenderer.ShapeType.Filled);
        Color top = new Color(.02f, .03f, .07f, 1f), bot = new Color(.10f, .13f, .22f, 1f);
        shapes.rect(0, 0, w, h, bot, bot, top, top);
        shapes.setColor(1f, .28f, .34f, .10f);
        shapes.rectLine(w * .30f, -h * .1f, w * .62f, h * 1.1f, h * .10f);
        shapes.setColor(.30f, .50f, 1f, .07f);
        shapes.rectLine(w * .40f, -h * .1f, w * .72f, h * 1.1f, h * .05f);
        for (int i = 4; i >= 1; i--) {
            shapes.setColor(.25f, .55f, 1f, .07f + .05f * (5 - i));
            shapes.ellipse(feet.x - rx * i / 4f, feet.y - ry * i / 4f, 2f * rx * i / 4f, 2f * ry * i / 4f);
        }
        shapes.end();
        Gdx.gl.glDisable(GL20.GL_BLEND);

        // Personagem 3D girando devagar (arraste para girar manualmente)
        if (lobbyCharacter != null) {
            if (!draggingLobby) lobbyYaw += 16f * dt;
            float bob = MathUtils.sin(worldTime * 1.6f) * .015f;
            lobbyCharacter.transform.idt().translate(0f, bob, 0f).rotate(Vector3.Y, lobbyYaw);
            Gdx.gl.glClear(GL20.GL_DEPTH_BUFFER_BIT);
            modelBatch.begin(lobbyCam);
            modelBatch.render(lobbyCharacter, lobbyEnv);
            modelBatch.end();
        }
    }

    private void startReload() {
        if (reloading || screen != Screen.PLAYING || ammo >= weaponAmmo[weapon]) return;
        reloading = true; reloadTimer = 0f; ads = false;
    }

    private void updateEffects(float dt) {
        if (reloading) {
            ads = false;
            reloadTimer += dt;
            if (reloadTimer >= weaponReload[weapon]) { reloading = false; ammo = weaponAmmo[weapon]; }
        } else if (ammo <= 0) {
            startReload();   // recarga automatica
        }
        flashT = Math.max(0f, flashT - dt);
        float len = 2.5f;
        for (int i = tracers.size - 1; i >= 0; i--) {
            Tracer t = tracers.get(i);
            t.traveled += dt * 150f;
            float tail = Math.max(0f, t.traveled - len), head = Math.min(t.traveled, t.total);
            if (tail >= t.total) { tracers.removeIndex(i); continue; }
            float l = head - tail;
            if (l < .05f) { t.visible = false; continue; }
            t.visible = true;
            tmp2.set(t.dir).scl((head + tail) * .5f).add(t.pos);
            Vector3 up = Math.abs(t.dir.y) > .98f ? Vector3.X : Vector3.Y;
            t.inst.transform.setToWorld(tmp2, t.dir, up);
            t.inst.transform.scale(1f, 1f, l / len);
        }
        for (int i = casings.size - 1; i >= 0; i--) {
            Casing c = casings.get(i);
            c.life -= dt;
            if (c.life <= 0f) { casings.removeIndex(i); continue; }
            if (!c.landed) {
                c.vel.y -= 9.8f * dt;
                c.pos.mulAdd(c.vel, dt);
                c.rx += c.sx * dt; c.ry += c.sy * dt;
                if (c.pos.y < .012f) {
                    c.pos.y = .012f;
                    if (Math.abs(c.vel.y) < 1.2f) { c.landed = true; c.rx = 90f; }
                    else { c.vel.y = -c.vel.y * .35f; c.vel.x *= .55f; c.vel.z *= .55f; c.sx *= .5f; c.sy *= .5f; }
                }
            }
            c.inst.transform.setToTranslation(c.pos).rotate(Vector3.Y, c.ry).rotate(Vector3.X, c.rx).scale(c.scale, c.scale, c.scale);
        }
    }

    private void spawnTracer(float dist) {
        // Traçante saindo bem na frente do eixo da câmera (centro da mira)
        Vector3 muzzle = camera.position.cpy().mulAdd(camera.direction, 0.75f);
        Vector3 target = camera.position.cpy().mulAdd(camera.direction, dist);
        Tracer t = new Tracer();
        t.pos.set(muzzle);
        t.dir.set(camera.direction).nor();
        t.total = dist;
        t.inst = new ModelInstance(tracerModel);
        tracers.add(t);
        if (tracers.size > 30) tracers.removeIndex(0);
    }

    private void spawnCasing() {
        Vector3 right = camera.direction.cpy().crs(camera.up).nor();
        Casing c = new Casing();
        c.pos.set(camera.position).mulAdd(camera.direction, .45f).mulAdd(right, .19f).mulAdd(camera.up, -.11f);
        c.vel.set(right).scl(1.3f + random.nextFloat() * .9f)
            .mulAdd(camera.up, 1.5f + random.nextFloat() * .9f)
            .mulAdd(camera.direction, (random.nextFloat() - .5f) * .8f);
        c.sx = (random.nextFloat() - .5f) * 1400f;
        c.sy = (random.nextFloat() - .5f) * 1400f;
        c.life = 6f;
        c.scale = casingScale[weapon];
        c.inst = new ModelInstance(casingModel);
        casings.add(c);
        if (casings.size > 40) casings.removeIndex(0);
    }

    // ----- Personalizar HUD -----
    private void defaultCtl(float w, float h) {
        float[] dx = {.248f * h / w, (w - .25f * h) / w, (w - .25f * h) / w, (w - .48f * h) / w, (w - .46f * h) / w, (w - .09f * h) / w};
        float[] dy = {.248f, .27f, .52f, .31f, .52f, .91f};
        for (int i = 0; i < 6; i++) { ctlX[i] = dx[i]; ctlY[i] = dy[i]; }
    }
    private void loadHudPrefs() {
        try {
            prefs = Gdx.app.getPreferences("strikearena");
            hudScale = MathUtils.clamp(prefs.getFloat("hudScale", 1f), HUD_MIN, HUD_MAX);
            playerName = prefs.getString("playerName", "Soldado");
            lobbyCharacterIndex = prefs.getInteger("lobbyCharacterIndex", -1);
            hudCustom = prefs.getBoolean("hudCustom", false);
            if (hudCustom) for (int i = 0; i < 6; i++) { ctlX[i] = prefs.getFloat("cx" + i, .5f); ctlY[i] = prefs.getFloat("cy" + i, .5f); }
        } catch (Exception ex) { hudCustom = false; hudScale = 1f; }
    }
    private void saveHudPrefs() {
        if (prefs == null) return;
        prefs.putFloat("hudScale", hudScale);
        prefs.putBoolean("hudCustom", hudCustom);
        for (int i = 0; i < 6; i++) { prefs.putFloat("cx" + i, ctlX[i]); prefs.putFloat("cy" + i, ctlY[i]); }
        prefs.flush();
    }
    private boolean inBox(float x, float y, float rx, float ry, float rw, float rh) {
        return x >= rx && x <= rx + rw && y >= ry && y <= ry + rh;
    }
    private void layoutEditorGeom(float w, float h) {
        lsX0 = w * .30f; lsX1 = w * .70f; lsY = h * .86f;
        lbW = w * .20f; lbH = h * .085f; lbY = h * .66f;
        lbRX = w / 2f - lbW - w * .012f; lbDX = w / 2f + w * .012f;
    }
    private void setHudScaleFromX(float x) {
        float t = MathUtils.clamp((x - lsX0) / (lsX1 - lsX0), 0f, 1f);
        hudScale = HUD_MIN + t * (HUD_MAX - HUD_MIN);
    }
    private boolean ctlHit(int i, float x, float yy) {
        float[] cx = {jX, fX, pX, aX, rX, pauseX}, cy = {jY, fY, pY, aY, rY, pauseY}, r = {jR, fR, pR, aR, rR, pauseR};
        return hit(x, yy, cx[i], cy[i], r[i] * 1.1f);
    }
    private boolean layoutEditorTouch(float x, float yy) {
        float w = Gdx.graphics.getWidth(), h = Gdx.graphics.getHeight();
        layoutTouch(w, h); layoutEditorGeom(w, h);
        if (Math.abs(yy - lsY) <= h * .07f && x >= lsX0 - h * .05f && x <= lsX1 + h * .05f) {
            draggingHudScale = true; setHudScaleFromX(x); return true;
        }
        if (inBox(x, yy, lbRX, lbY, lbW, lbH)) { hudCustom = false; hudScale = 1f; saveHudPrefs(); return true; }
        if (inBox(x, yy, lbDX, lbY, lbW, lbH)) { saveHudPrefs(); screen = Screen.PAUSED; return true; }
        for (int i = 5; i >= 0; i--) {
            if (ctlHit(i, x, yy)) {
                hudCustom = true;
                layoutDrag = i; dragDX = ctlX[i] * w - x; dragDY = ctlY[i] * h - yy;
                return true;
            }
        }
        return true;
    }
    private void layoutEditorDrag(float x, float yy) {
        float w = Gdx.graphics.getWidth(), h = Gdx.graphics.getHeight();
        layoutEditorGeom(w, h);
        if (draggingHudScale) { setHudScaleFromX(x); return; }
        if (layoutDrag >= 0) {
            ctlX[layoutDrag] = MathUtils.clamp((x + dragDX) / w, .03f, .97f);
            ctlY[layoutDrag] = MathUtils.clamp((yy + dragDY) / h, .05f, .95f);
        }
    }
    private void drawLayoutEditor(float w, float h) {
        layoutTouch(w, h); layoutEditorGeom(w, h);
        Gdx.gl.glEnable(GL20.GL_BLEND);
        Gdx.gl.glBlendFunc(GL20.GL_SRC_ALPHA, GL20.GL_ONE_MINUS_SRC_ALPHA);
        shapes.begin(ShapeRenderer.ShapeType.Filled);
        shapes.setColor(0, 0, 0, .62f); shapes.rect(0, 0, w, h);
        shapes.end();
        Gdx.gl.glDisable(GL20.GL_BLEND);
        drawTouchControls(w, h);
        Gdx.gl.glEnable(GL20.GL_BLEND);
        Gdx.gl.glBlendFunc(GL20.GL_SRC_ALPHA, GL20.GL_ONE_MINUS_SRC_ALPHA);
        shapes.begin(ShapeRenderer.ShapeType.Filled);
        if (layoutDrag >= 0) {
            float[] cx = {jX, fX, pX, aX, rX, pauseX}, cy = {jY, fY, pY, aY, rY, pauseY}, r = {jR, fR, pR, aR, rR, pauseR};
            shapes.setColor(1, 1, 1, .9f);
            ring(cx[layoutDrag], cy[layoutDrag], r[layoutDrag] * 1.08f, h * .004f, 48);
        }
        float t = (hudScale - HUD_MIN) / (HUD_MAX - HUD_MIN);
        float kx = lsX0 + t * (lsX1 - lsX0);
        shapes.setColor(1, 1, 1, .20f); shapes.rect(lsX0, lsY - h * .008f, lsX1 - lsX0, h * .016f);
        shapes.setColor(1f, .28f, .34f, 1f); shapes.rect(lsX0, lsY - h * .008f, kx - lsX0, h * .016f);
        shapes.setColor(1, 1, 1, 1); shapes.circle(kx, lsY, h * .032f);
        shapes.end();
        Gdx.gl.glDisable(GL20.GL_BLEND);
        shapes.begin(ShapeRenderer.ShapeType.Filled);
        drawButton(lbRX, lbY, lbW, lbH, new Color(.35f, .18f, .18f, 1f), new Color(.6f, .3f, .3f, 1f));
        drawButton(lbDX, lbY, lbW, lbH, new Color(.15f, .45f, .25f, 1f), new Color(.3f, .7f, .4f, 1f));
        shapes.end();
        hud.begin();
        float sx = font.getData().scaleX, sy = font.getData().scaleY;
        font.getData().setScale(h / 700f);
        font.setColor(Color.WHITE);
        font.draw(hud, "TAMANHO DO HUD", lsX0, lsY + h * .085f);
        String sv = String.format(Locale.US, "%.2f", hudScale);
        layout.setText(font, sv);
        font.draw(hud, sv, lsX1 - layout.width, lsY + h * .085f);
        centerLabel("RESTAURAR PADRÃO", lbRX + lbW / 2f, lbY + lbH / 2f);
        centerLabel("CONCLUIR", lbDX + lbW / 2f, lbY + lbH / 2f);
        font.setColor(Color.LIGHT_GRAY);
        centerLabel("Arraste os botões para mudar a posição", w / 2f, h * .60f);
        font.getData().setScale(sx, sy);
        hud.end();
    }

    private void loadCharacters() {
        for (String id : CHAR_IDS) {
            try {
                Texture tex = new Texture(Gdx.files.internal("models/texture-" + id + ".png"));
                tex.setFilter(Texture.TextureFilter.Linear, Texture.TextureFilter.Linear);
                Model m = new ObjLoader().loadModel(Gdx.files.internal("models/character-" + id + ".obj"), false);
                for (Material mat : m.materials) {
                    mat.set(ColorAttribute.createDiffuse(Color.WHITE));
                    mat.set(TextureAttribute.createDiffuse(tex));
                }
                charTextures.add(tex);
                charModels.add(m);
            } catch (Exception ex) {
                Gdx.app.error("StrikeArena", "Falha ao carregar personagem " + id, ex);
            }
        }
    }

    private Model materialBox(float w, float h, float d, Color color) {
        return modelBuilder.createBox(w, h, d,
            new Material(ColorAttribute.createDiffuse(color)),
            VertexAttributes.Usage.Position | VertexAttributes.Usage.Normal);
    }
    private void buildWorld() {
        // ===== Mapa grande (~400x400) com grama procedural leve =====
        final float MAP = 400f;
        // Textura de grama mais saturada e com variação (64x64)
        Pixmap grassPix = new Pixmap(64, 64, Pixmap.Format.RGBA8888);
        for (int y = 0; y < 64; y++) {
            for (int x = 0; x < 64; x++) {
                float n = ((x * 7 + y * 13) % 17) / 17f;
                float n2 = ((x * 3 + y * 11) % 11) / 11f;
                // Mais saturação: verde vivo + leve variação amarelada
                float r = 0.12f + n * 0.10f + n2 * 0.06f;
                float g = 0.42f + n * 0.38f + n2 * 0.12f;   // bem mais verde
                float b = 0.06f + n * 0.08f;
                grassPix.setColor(r, g, b, 1f);
                grassPix.drawPixel(x, y);
            }
        }
        grassTexture = new Texture(grassPix);
        grassTexture.setWrap(Texture.TextureWrap.Repeat, Texture.TextureWrap.Repeat);
        grassTexture.setFilter(Texture.TextureFilter.Linear, Texture.TextureFilter.Linear);
        grassPix.dispose();

        // Multiplicador de cor um pouco mais saturado no material
        Color grassTint = new Color(0.85f, 1.15f, 0.75f, 1f);
        floorModel = modelBuilder.createBox(MAP, .2f, MAP,
            new Material(TextureAttribute.createDiffuse(grassTexture), ColorAttribute.createDiffuse(grassTint)),
            VertexAttributes.Usage.Position | VertexAttributes.Usage.Normal | VertexAttributes.Usage.TextureCoordinates);

        wallModel = materialBox(MAP + 2, 6f, 2.2f, new Color(.22f, .25f, .32f, 1));
        crateModel = materialBox(2.4f, 1.8f, 2.4f, new Color(.38f, .42f, .50f, 1));
        houseModel = materialBox(8f, 4.5f, 7f, new Color(.52f, .45f, .36f, 1));
        roofModel = materialBox(9.2f, 1.2f, 8.2f, new Color(.48f, .22f, .18f, 1));

        enemyBodyModel = modelBuilder.createCapsule(.32f, 1.1f, 8,
            new Material(ColorAttribute.createDiffuse(new Color(.63f, .13f, .12f, 1))),
            VertexAttributes.Usage.Position | VertexAttributes.Usage.Normal);
        enemyHeadModel = modelBuilder.createSphere(.44f, .44f, .44f, 8, 8,
            new Material(ColorAttribute.createDiffuse(new Color(.78f, .22f, .18f, 1))),
            VertexAttributes.Usage.Position | VertexAttributes.Usage.Normal);

        // Textura arma
        Pixmap gunPix = new Pixmap(64, 64, Pixmap.Format.RGBA8888);
        for (int y = 0; y < 64; y++) {
            for (int x = 0; x < 64; x++) {
                float n = (x + y * 0.7f) % 16 < 8 ? 0.18f : 0.28f;
                gunPix.setColor(n, n * 1.05f, n * 1.15f, 1f);
                gunPix.drawPixel(x, y);
            }
        }
        gunPix.setColor(0.35f, 0.37f, 0.42f, 1f);
        gunPix.fillRectangle(20, 0, 24, 64);
        gunTexture = new Texture(gunPix);
        gunTexture.setFilter(Texture.TextureFilter.Linear, Texture.TextureFilter.Linear);
        gunPix.dispose();
        gunModel = modelBuilder.createBox(.12f, .12f, .42f,
            new Material(TextureAttribute.createDiffuse(gunTexture), ColorAttribute.createDiffuse(Color.WHITE)),
            VertexAttributes.Usage.Position | VertexAttributes.Usage.Normal | VertexAttributes.Usage.TextureCoordinates);
        pickupModel = materialBox(.48f, .14f, .14f, new Color(.10f, .85f, .38f, 1));
        moneyChestModel = materialBox(.72f, .48f, .58f, new Color(.72f, .43f, .10f, 1));
        enemyGunModel = materialBox(.12f, .10f, .62f, new Color(.12f, .13f, .15f, 1));
        knifeBladeModel = modelBuilder.createBox(.075f, .035f, .52f,
            new Material(ColorAttribute.createDiffuse(new Color(.72f,.78f,.84f,1))),
            VertexAttributes.Usage.Position | VertexAttributes.Usage.Normal);
        knifeHandleModel = materialBox(.09f, .075f, .22f, new Color(.16f,.12f,.09f,1));

        // Chão
        staticWorld.add(new ModelInstance(floorModel, 0, -.1f, 0));

        // Paredes externas (mapa grande)
        float half = MAP * 0.5f;
        staticWorld.add(new ModelInstance(wallModel, 0, 3f, -half));
        staticWorld.add(new ModelInstance(wallModel, 0, 3f, half));
        Model sideWall = materialBox(2.2f, 6f, MAP + 2, new Color(.18f, .20f, .26f, 1));
        generatedWorldModels.add(sideWall);
        staticWorld.add(new ModelInstance(sideWall, -half, 3f, 0));
        staticWorld.add(new ModelInstance(sideWall, half, 3f, 0));

        // Caixas espalhadas
        for (int i = 0; i < 55; i++) {
            float x = (random.nextFloat() - .5f) * (MAP - 30);
            float z = (random.nextFloat() - .5f) * (MAP - 30);
            if (Math.abs(x) < 12 && Math.abs(z) < 12) continue;
            ModelInstance box = new ModelInstance(crateModel, x, .9f, z);
            box.transform.rotate(Vector3.Y, random.nextFloat() * 360);
            staticWorld.add(box);
            BoundingBox bb = new BoundingBox();
            // Caixa rotacionada: cobre a diagonal e a face superior real do modelo.
            float crateRadius = (float)Math.sqrt(1.2f * 1.2f + 1.2f * 1.2f);
            bb.set(new Vector3(x - crateRadius, 0, z - crateRadius),
                   new Vector3(x + crateRadius, 1.8f, z + crateRadius));
            colliders.add(bb);
        }

        // Casas (construções simples)
        float[][] housePos = {
            {40, 35}, {-55, 20}, {70, -40}, {-30, -60}, {20, 80},
            {-80, -25}, {90, 50}, {-45, 70}, {15, -90}, {-70, 55}
        };
        for (float[] hp : housePos) {
            float hx = hp[0], hz = hp[1];
            // Casa com vão de porta na parede frontal (z positivo), permitindo entrar.
            Model houseWall = materialBox(8f, 4.5f, .45f, new Color(.42f, .38f, .32f, 1)); generatedWorldModels.add(houseWall);
            Model sideHouseWall = materialBox(.45f, 4.5f, 7f, new Color(.42f, .38f, .32f, 1)); generatedWorldModels.add(sideHouseWall);
            Model doorSide = materialBox(2.65f, 4.5f, .45f, new Color(.42f, .38f, .32f, 1)); generatedWorldModels.add(doorSide);
            Model lintel = materialBox(2.7f, 1.15f, .45f, new Color(.42f, .38f, .32f, 1)); generatedWorldModels.add(lintel);
            staticWorld.add(new ModelInstance(houseWall, hx, 2.25f, hz - 3.3f));
            staticWorld.add(new ModelInstance(sideHouseWall, hx - 3.8f, 2.25f, hz));
            staticWorld.add(new ModelInstance(sideHouseWall, hx + 3.8f, 2.25f, hz));
            staticWorld.add(new ModelInstance(doorSide, hx - 2.65f, 2.25f, hz + 3.3f));
            staticWorld.add(new ModelInstance(doorSide, hx + 2.65f, 2.25f, hz + 3.3f));
            staticWorld.add(new ModelInstance(lintel, hx, 3.95f, hz + 3.3f));
            staticWorld.add(new ModelInstance(roofModel, hx, 5.1f, hz));
            addWallCollider(hx, 2.25f, hz - 3.3f, 8f, 4.5f, .55f);
            addWallCollider(hx - 3.8f, 2.25f, hz, .55f, 4.5f, 7f);
            addWallCollider(hx + 3.8f, 2.25f, hz, .55f, 4.5f, 7f);
            addWallCollider(hx - 2.65f, 2.25f, hz + 3.3f, 2.8f, 4.5f, .55f);
            addWallCollider(hx + 2.65f, 2.25f, hz + 3.3f, 2.8f, 4.5f, .55f);
            // Os baús são instanciados no início de cada partida.
        }

        // Far plane maior + neblina leve pra distância (economia de performance)
        camera.far = 320f;
        environment.set(new ColorAttribute(ColorAttribute.Fog, 0.55f, 0.62f, 0.72f, 1f));
    }

    private void addWallCollider(float x, float y, float z, float w, float h, float d) {
        BoundingBox bb = new BoundingBox();
        bb.set(new Vector3(x-w/2f, y-h/2f, z-d/2f), new Vector3(x+w/2f, y+h/2f, z+d/2f));
        colliders.add(bb);
    }
    private void spawnCashChest(float x, float z) {
        Pickup p = new Pickup(); p.cash = true; p.cashValue = 80 + random.nextInt(171);
        p.position.set(x, 0, z); p.model = new ModelInstance(moneyChestModel); pickups.add(p);
    }
    private void populateCashChests() {
        float[][] housePos = {{40,35},{-55,20},{70,-40},{-30,-60},{20,80},{-80,-25},{90,50},{-45,70},{15,-90},{-70,55}};
        for (float[] pos : housePos) {
            spawnCashChest(pos[0] + (random.nextFloat()-.5f)*3.5f,
                           pos[1] + (random.nextFloat()-.5f)*3.5f);
        }
        for (int i=0; i<24; i++) spawnCashChest((random.nextFloat()-.5f)*340f,
                                                 (random.nextFloat()-.5f)*340f);
    }

    @Override public void render() {
        float dt=Math.min(Gdx.graphics.getDeltaTime(),.05f);
        worldTime += dt;
        // Controles sempre (menu + jogo)
        pollController(dt);
        if (screen == Screen.PLAYING) updateGame(dt);
        Gdx.gl.glViewport(0,0,Gdx.graphics.getWidth(),Gdx.graphics.getHeight());
        if (lobbyScene()) {
            // Lobby: cena própria com o personagem 3D do jogador (sem o mapa).
            renderLobby(dt);
            drawHud();
            return;
        }
        // Céu claro com tom azulado (nuvens simuladas pelo fog + cor)
        Gdx.gl.glClearColor(0.45f, 0.62f, 0.85f, 1f);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT | GL20.GL_DEPTH_BUFFER_BIT);
        camera.update();
        modelBatch.begin(camera);
        for (ModelInstance m: staticWorld) modelBatch.render(m,environment);
        for (Enemy e: enemies) { modelBatch.render(e.body,environment); if (e.head != null) modelBatch.render(e.head,environment); if (e.weapon != null) modelBatch.render(e.weapon,environment); }
        for (Pickup p: pickups) modelBatch.render(p.model,environment);
        for (Casing c: casings) modelBatch.render(c.inst,environment);
        for (Particle p: particles) modelBatch.render(p.inst,environment);
        for (Tracer t: tracers) if (t.visible) modelBatch.render(t.inst,environment);
        modelBatch.end();
        if (screen == Screen.PLAYING) renderViewModel();
        drawHud();
        if (mobile) drawTouchPointers();
    }

    private void updateGame(float dt) {
        if (mobile && firing) fire();
        updateMovement(dt);
        spawnTimer += dt;
        int alive = 0;
        for (Enemy en : enemies) if (!en.dying) alive++;
        if (spawnTimer >= 2.7f && alive < 10) { spawnTimer=0; spawnEnemy(); }
        for (int i=enemies.size-1;i>=0;i--) {
            Enemy e=enemies.get(i);
            if (e.dying) {
                // Animação de morte: cai, fica no chão, afunda e desaparece.
                e.deathTime += dt;
                if (e.deathTime >= DEATH_TOTAL) { enemies.removeIndex(i); continue; }
                updateEnemyTransform(e);
                continue;
            }
            Vector3 to=camera.position.cpy().sub(e.position); to.y=0;
            float faceX=to.x, faceZ=to.z;
            float dist=to.len();
            if (dist>1.55f) { to.nor().scl(e.speed*dt); e.position.add(to); }
            e.facing = MathUtils.atan2(faceX, faceZ) * MathUtils.radiansToDegrees;
            updateEnemyTransform(e);
            e.attackTimer-=dt;
            e.shotTimer-=dt;
            if (dist < 22f && e.shotTimer <= 0f) {
                e.shotTimer = 1.25f + random.nextFloat() * 1.2f;
                // Dispersão deliberada: inimigos têm menor precisão que o jogador.
                float missChance = .48f;
                enemyShotIndicator = .65f;
                enemyShotAngle = MathUtils.atan2(e.position.x - camera.position.x, e.position.z - camera.position.z);
                if (random.nextFloat() > missChance) {
                    float damage = 5f + random.nextFloat() * 4f;
                    damagePlayer((int)damage);
                }
            }
            if (dist<1.85f && e.attackTimer<=0) { e.attackTimer=1; damagePlayer(8); }
        }
        updateParticles(dt);
        killPulse = Math.max(0f, killPulse - dt * 2.2f);
        killFeedT = Math.max(0f, killFeedT - dt);
        hitMarkerT = Math.max(0f, hitMarkerT - dt);
        for (int i=pickups.size-1;i>=0;i--) {
            Pickup p=pickups.get(i);
            p.phase += dt;
            p.model.transform.setToTranslation(p.position.x,.55f+MathUtils.sin(p.phase*2.2f)*.09f,p.position.z);
            p.model.transform.rotate(Vector3.Y,dt*70);
            if (p.position.dst(camera.position.x,0,camera.position.z)<1.45f) {
                if (p.cash) money += p.cashValue;
                else hp=Math.min(100,hp+28);
                pickups.removeIndex(i);
            }
        }
        if (worldTime-lastDamage>3.8f && hp<100) { regenTimer+=7*dt; if(regenTimer>=1){hp=Math.min(100,hp+1);regenTimer=0;} }
        vestRegenDelay = Math.max(0f, vestRegenDelay - dt);
        if (vestRegenDelay <= 0f && energyVest < 100) {
            vestRegenTimer += dt;
            if (vestRegenTimer >= .16f) {
                int recharge = Math.max(1, (int)(vestRegenTimer / .16f));
                energyVest = Math.min(100, energyVest + recharge);
                vestRegenTimer -= recharge * .16f;
            }
        } else if (vestRegenDelay > 0f) vestRegenTimer = 0f;
        enemyShotIndicator = Math.max(0f, enemyShotIndicator - dt);
    }

    private void updateMovement(float dt) {
        float mx=0,mz=0;
        if (mobile) { mx=moveX; mz=moveY; }
        else {
            if(moveForward) mz-=1; if(moveBack) mz+=1; if(moveLeft) mx-=1; if(moveRight) mx+=1;
        }
        // Gamepad sobrescreve / soma movimento
        if (padConnected && (Math.abs(padMoveX) > 0.01f || Math.abs(padMoveY) > 0.01f)) {
            mx = padMoveX;
            mz = padMoveY;
        }
        float len=(float)Math.sqrt(mx*mx+mz*mz); if(len>1){mx/=len;mz/=len;}
        forward.set(camera.direction.x,0,camera.direction.z).nor();
        right.set(forward).crs(Vector3.Y).nor();
        move.set(forward).scl(-mz).mulAdd(right,mx).scl(7.8f);
        Vector3 oldPos = camera.position.cpy();
        float oldFeet = oldPos.y - 1.7f;
        camera.position.mulAdd(move, dt);
        // Colisão horizontal com margem do jogador e resolução por eixo.
        for (BoundingBox bb : colliders) {
            float cx = (bb.min.x + bb.max.x) * 0.5f;
            float cz = (bb.min.z + bb.max.z) * 0.5f;
            float hx = (bb.max.x - bb.min.x) * 0.5f + 0.42f;
            float hz = (bb.max.z - bb.min.z) * 0.5f + 0.42f;
            boolean verticallyOverlapping = camera.position.y - 1.7f < bb.max.y - 0.05f
                    && camera.position.y + 0.25f > bb.min.y;
            if (verticallyOverlapping && Math.abs(camera.position.x - cx) < hx
                    && Math.abs(camera.position.z - cz) < hz) {
                if (Math.abs(camera.position.x - cx) > Math.abs(camera.position.z - cz)) {
                    camera.position.x = oldPos.x;
                    if (Math.abs(camera.position.z - cz) < hz) camera.position.z = oldPos.z;
                } else {
                    camera.position.z = oldPos.z;
                    if (Math.abs(camera.position.x - cx) < hx) camera.position.x = oldPos.x;
                }
            }
        }
        // A face superior também é sólida: permite pousar em caixas/telhados ao saltar.
        velocity.y -= 28 * dt;
        float nextY = camera.position.y + velocity.y * dt;
        float nextFeet = nextY - 1.7f;
        if (velocity.y <= 0f) {
            for (BoundingBox bb : colliders) {
                float cx = (bb.min.x + bb.max.x) * 0.5f;
                float cz = (bb.min.z + bb.max.z) * 0.5f;
                float hx = (bb.max.x - bb.min.x) * 0.5f + 0.30f;
                float hz = (bb.max.z - bb.min.z) * 0.5f + 0.30f;
                boolean overlapsTop = Math.abs(camera.position.x - cx) < hx
                        && Math.abs(camera.position.z - cz) < hz;
                if (overlapsTop && oldFeet >= bb.max.y - 0.12f && nextFeet <= bb.max.y) {
                    nextY = bb.max.y + 1.7f;
                    velocity.y = 0f;
                    break;
                }
            }
        }
        camera.position.y = nextY;
        if (camera.position.y < 1.7f) { camera.position.y = 1.7f; velocity.y = 0; }
        float limit = 195f;
        camera.position.x = MathUtils.clamp(camera.position.x, -limit, limit);
        camera.position.z = MathUtils.clamp(camera.position.z, -limit, limit);
        if (mobile && (lookX!=0 || lookY!=0)) {
            float fs = MathUtils.clamp(camera.fieldOfView/75f,.2f,1f);
            yaw -= lookX*.0038f*sens*fs;
            pitch -= lookY*.0038f*sens*fs;
            lookX=lookY=0;
        }
        // Look do gamepad (analógico direito)
        if (padConnected && (Math.abs(padLookX) > 0.01f || Math.abs(padLookY) > 0.01f)) {
            float fs = MathUtils.clamp(camera.fieldOfView / 75f, 0.25f, 1f);
            float speed = 2.6f * sens * fs * dt;
            yaw -= padLookX * speed;
            pitch -= padLookY * speed;
        }
        // Tracking / aim assist (sempre que estiver jogando e aimAssist ligado)
        if (aimAssist && screen == Screen.PLAYING) {
            applyTargetTracking(dt);
        }
        if (jumpRequested && camera.position.y<=1.71f) velocity.y=11;
        jumpRequested=false;
        pitch=MathUtils.clamp(pitch,-1.35f,1.35f);
        // Eixos da câmera corrigidos: yaw positivo = virar pra direita, pitch positivo = olhar pra cima
        camera.direction.set(
            -MathUtils.sin(yaw) * MathUtils.cos(pitch),
            MathUtils.sin(pitch),
            -MathUtils.cos(yaw) * MathUtils.cos(pitch)
        ).nor();
        camera.up.set(Vector3.Y);
        camera.fieldOfView += ((ads?weaponAdsFov[weapon]:75)-camera.fieldOfView)*Math.min(1,dt*10);
        adsT += ((ads?1f:0f)-adsT)*Math.min(1f,dt*11f);
        kick = Math.max(0f,kick-dt*7f);
        updateEffects(dt);
    }

    // Posiciona o corpo/cabeça/arma do inimigo (vivo ou em animação de morte).
    // Adiciona bob de caminhada + leve balanço (simula movimento de braços/pernas).
    private void updateEnemyTransform(Enemy e) {
        float angle = 0f, lift = 0f, knock = 0f, sink = 0f, alpha = 1f;
        float walkBob = 0f, lean = 0f, armSwing = 0f;
        if (e.dying) {
            float t = e.deathTime;
            float f = MathUtils.clamp(t / DEATH_FALL, 0f, 1f);
            float ease = 1f - (1f - f) * (1f - f) * (1f - f);
            angle = -90f * ease;
            lift = (e.skinned ? .26f : .32f) * ease;
            knock = .8f * ease;
            float fadeStart = DEATH_FALL + DEATH_LIE;
            if (t > fadeStart) {
                float k = MathUtils.clamp((t - fadeStart) / DEATH_FADE, 0f, 1f);
                alpha = 1f - k;
                sink = .3f * k;
            }
        } else {
            // Ciclo de caminhada baseado no tempo e velocidade
            float cycle = worldTime * e.speed * 2.8f + e.position.x * 0.4f;
            walkBob = MathUtils.sin(cycle) * 0.06f;
            lean = MathUtils.sin(cycle * 0.5f) * 4.5f;          // leve inclinação lateral
            armSwing = MathUtils.sin(cycle) * 12f;              // balanço (usado na arma/cabeça)
        }
        enemyBase.idt().translate(e.position.x + e.fallDir.x * knock,
                                  e.position.y + lift - sink + walkBob,
                                  e.position.z + e.fallDir.z * knock)
                 .rotate(Vector3.Y, e.facing)
                 .rotate(Vector3.Z, lean)
                 .rotate(Vector3.X, angle);
        if (e.skinned) {
            e.body.transform.set(enemyBase).scale(CHAR_SCALE, CHAR_SCALE, CHAR_SCALE);
        } else {
            e.body.transform.set(enemyBase).translate(0f, .75f, 0f);
            if (e.head != null) {
                e.head.transform.set(enemyBase).translate(0f, 1.55f, 0f)
                    .rotate(Vector3.X, armSwing * 0.15f); // cabeça acompanha um pouco
            }
        }
        if (e.weapon != null) {
            // Arma balança como se o braço estivesse se movendo
            e.weapon.transform.set(enemyBase)
                .translate(.50f, .80f + walkBob * 0.5f, .30f)
                .rotate(Vector3.X, armSwing * 0.6f)
                .rotate(Vector3.Z, -armSwing * 0.25f);
        }
        if (e.dying && alpha < 1f) {
            setAlpha(e.body, alpha); setAlpha(e.head, alpha); setAlpha(e.weapon, alpha);
        }
    }

    private void setAlpha(ModelInstance mi, float a) {
        if (mi == null) return;
        for (Material m : mi.materials) {
            BlendingAttribute ba = m.get(BlendingAttribute.class, BlendingAttribute.Type);
            if (ba == null) m.set(new BlendingAttribute(true, GL20.GL_SRC_ALPHA, GL20.GL_ONE_MINUS_SRC_ALPHA, a));
            else ba.opacity = a;
        }
    }

    private void spawnBlood(float x, float y, float z, int count, float power) {
        for (int i = 0; i < count; i++) {
            Particle p = new Particle();
            p.pos.set(x + (random.nextFloat() - .5f) * .3f, y + (random.nextFloat() - .5f) * .3f, z + (random.nextFloat() - .5f) * .3f);
            p.vel.set((random.nextFloat() - .5f) * 4f * power, 1.2f + random.nextFloat() * 2.6f * power, (random.nextFloat() - .5f) * 4f * power);
            p.maxLife = p.life = .45f + random.nextFloat() * .45f;
            p.size = .7f + random.nextFloat() * .9f;
            p.inst = new ModelInstance(particleModel);
            particles.add(p);
        }
        while (particles.size > 120) particles.removeIndex(0);
    }

    private void updateParticles(float dt) {
        for (int i = particles.size - 1; i >= 0; i--) {
            Particle p = particles.get(i);
            p.life -= dt;
            if (p.life <= 0f) { particles.removeIndex(i); continue; }
            p.vel.y -= 12f * dt;
            p.pos.mulAdd(p.vel, dt);
            if (p.pos.y < .04f) { p.pos.y = .04f; p.vel.set(p.vel.x * .4f, 0f, p.vel.z * .4f); }
            float sc = p.size * (p.life / p.maxLife);
            p.inst.transform.setToTranslation(p.pos).scale(sc, sc, sc);
        }
    }

    // Registra a eliminação: contador, recompensa, feedback visual e início da animação de morte.
    private void killEnemy(Enemy e, boolean allowDrop) {
        if (e.dying) return;
        e.dying = true; e.deathTime = 0f; e.hp = 0f;
        kills++;
        lastKillReward = 50 + random.nextInt(30);
        money += lastKillReward;
        killPulse = 1f; killFeedT = 1.6f; hitMarkerT = .30f; hitMarkerKill = true;
        e.fallDir.set(e.position.x - camera.position.x, 0f, e.position.z - camera.position.z);
        if (e.fallDir.len2() < .0001f) e.fallDir.set(0f, 0f, -1f);
        e.fallDir.nor();
        spawnBlood(e.position.x, e.position.y + 1.0f, e.position.z, 16, 1.2f);
        int healthPickups = 0;
        for (Pickup q : pickups) if (!q.cash) healthPickups++;
        if (allowDrop && random.nextFloat() < .4f && healthPickups < 5) {
            Pickup p = new Pickup(); p.position.set(e.position); p.model = new ModelInstance(pickupModel); pickups.add(p);
        }
    }

    private void spawnEnemy() {
        Enemy e=new Enemy();
        float x,z;
        do { x=(random.nextFloat()-.5f)*360; z=(random.nextFloat()-.5f)*360; }
        while (Vector2.dst(x,z,camera.position.x,camera.position.z)<22);
        e.position.set(x,0,z); e.speed=3.0f*(.85f+random.nextFloat()*.3f);
        e.shotTimer = 1.2f + random.nextFloat() * 1.5f;
        e.weapon = new ModelInstance(enemyGunModel);
        if (charModels.size > 0) {
            e.body=new ModelInstance(charModels.get(random.nextInt(charModels.size)));
            e.skinned=true;
        } else {
            e.body=new ModelInstance(enemyBodyModel); e.head=new ModelInstance(enemyHeadModel);
        }
        updateEnemyTransform(e);
        enemies.add(e);
    }

    private void fire() {
        if(screen!=Screen.PLAYING || reloading) return;
        if (knifeEquipped) {
            if (worldTime - lastShot < .48f) return;
            lastShot = worldTime;
            Enemy closest = null; float nearest = 2.7f;
            for (Enemy e : enemies) {
                if (e.dying) continue;
                Vector3 to = e.position.cpy().add(0,1.1f,0).sub(camera.position);
                float d = to.len(); to.nor();
                if (d < nearest && camera.direction.dot(to) > .72f) { nearest=d; closest=e; }
            }
            if (closest != null) {
                closest.hp -= 42f;
                if (closest.hp <= 0f) killEnemy(closest, true);
                else { hitMarkerT = .18f; hitMarkerKill = false; spawnBlood(closest.position.x, closest.position.y + 1.1f, closest.position.z, 4, .6f); }
            }
            kick = .35f; return;
        }
        if(ammo<=0) { startReload(); return; }
        if(worldTime-lastShot<weaponRate[weapon]) return;
        lastShot=worldTime; ammo--; kick=1f;
        if (sfxShoot != null) sfxShoot.play(0.6f * volume);
        Vector3 dir = camera.direction.cpy().nor();
        // Raio de acerto em metros (corpo). Shotgun um pouco maior; sniper bem apertado.
        // A mira tem que passar PERTO do modelo — não basta estar "mais ou menos" na direção.
        float bodyR = weapon == 3 ? 0.55f : (weapon == 4 ? 0.28f : 0.38f);
        float headR = weapon == 3 ? 0.32f : (weapon == 4 ? 0.18f : 0.22f);
        if (ads) { bodyR *= 0.85f; headR *= 0.85f; } // ADS ainda mais preciso

        Enemy hit = null;
        float best = 999f;
        boolean headshot = false;
        for (Enemy e : enemies) {
            if (e.dying) continue;
            // Corpo (centro do peito)
            if (rayHitsSphere(camera.position, dir, e.position.x, e.position.y + 1.05f, e.position.z, bodyR)) {
                float d = camera.position.dst(e.position.x, e.position.y + 1.05f, e.position.z);
                if (d < best) { best = d; hit = e; headshot = false; }
            }
            // Cabeça (mais alta, raio menor)
            if (rayHitsSphere(camera.position, dir, e.position.x, e.position.y + 1.55f, e.position.z, headR)) {
                float d = camera.position.dst(e.position.x, e.position.y + 1.55f, e.position.z);
                if (d < best) { best = d; hit = e; headshot = true; }
            }
        }
        float tdist = hit != null ? best : 220f;
        if (hit == null) {
            float m = 220f;
            if (dir.x > .001f) m = Math.min(m, (195f - camera.position.x) / dir.x); else if (dir.x < -.001f) m = Math.min(m, (-195f - camera.position.x) / dir.x);
            if (dir.z > .001f) m = Math.min(m, (195f - camera.position.z) / dir.z); else if (dir.z < -.001f) m = Math.min(m, (-195f - camera.position.z) / dir.z);
            if (dir.y < -.001f) m = Math.min(m, (0f - camera.position.y) / dir.y);
            tdist = Math.max(3f, m);
        }
        spawnTracer(tdist); spawnCasing();
        flashT = .06f; flashScale = .8f + random.nextFloat() * .5f; flashRot = random.nextFloat() * 360f;
        if (hit != null) {
            if (sfxHit != null) sfxHit.play(0.5f * volume);
            float dmg = weaponDamage[weapon] * (ads ? 1.15f : 1f) * (headshot ? 1.45f : 1f);
            hit.hp -= dmg;
            if (hit.hp <= 0) killEnemy(hit, true);
            else {
                hitMarkerT = .18f; hitMarkerKill = false;
                spawnBlood(hit.position.x, hit.position.y + (headshot ? 1.5f : 1.1f), hit.position.z, 4, .6f);
            }
        }
    }

    /** Retorna true se o raio (origem + direção) passa a menos de radius do ponto (sx,sy,sz). */
    private boolean rayHitsSphere(Vector3 origin, Vector3 dir, float sx, float sy, float sz, float radius) {
        float ox = sx - origin.x, oy = sy - origin.y, oz = sz - origin.z;
        float proj = ox * dir.x + oy * dir.y + oz * dir.z;
        if (proj < 0f) return false; // atrás da câmera
        float closestSq = ox * ox + oy * oy + oz * oz - proj * proj;
        return closestSq <= radius * radius;
    }

    private void damagePlayer(int amount) {
        vestRegenDelay = 4.5f; lastDamage=worldTime; regenTimer=0;
        int absorbed = Math.min(energyVest, (int)Math.ceil(amount * .65f));
        energyVest -= absorbed;
        int remaining = Math.max(0, amount - absorbed);
        hp=Math.max(0,hp-remaining);
        if(hp<=0) {
            deathPos.set(camera.position);
            deathYaw = yaw;
            deathPitch = pitch;
            canRespawnHere = true;
            screen = Screen.DEAD;
            menuIndex = 0;
            firing = false;
            ads = false;
            unlockMouse();
        }
    }

    private void startGame() {
        screen=Screen.PLAYING; hp=100; energyVest=100; vestRegenDelay=0; kills=0; money=0; ammo=weaponAmmo[weapon]; knifeEquipped=false;
        tracers.clear(); casings.clear(); particles.clear(); reloading=false; flashT=0f;
        killPulse=0f; killFeedT=0f; hitMarkerT=0f; jumpRequested=false;
        enemies.clear(); pickups.clear(); populateCashChests(); camera.position.set(0,1.7f,0); yaw=pitch=0; velocity.setZero();
        spawnTimer=0; canRespawnHere=false; lockMouse();
    }
    private void respawnHere() {
        if (!canRespawnHere) { startGame(); return; }
        screen = Screen.PLAYING;
        hp = 100; energyVest = 100; vestRegenDelay = 0;
        ammo = weaponAmmo[weapon]; knifeEquipped = false;
        reloading = false; flashT = 0f; jumpRequested = false;
        camera.position.set(deathPos);
        camera.position.y = 1.7f;
        yaw = deathYaw; pitch = deathPitch;
        velocity.setZero();
        lockMouse();
    }
    private void restart() { startGame(); }
    private void lockMouse() { if(!mobile) Gdx.input.setCursorCatched(true); }
    private void unlockMouse() { Gdx.input.setCursorCatched(false); }

    private void drawHud() {
        float w=Gdx.graphics.getWidth(), h=Gdx.graphics.getHeight();
        hud.begin();
        if(screen==Screen.PLAYING) {
            float base = 1.15f * hudScale * uiScale(h);
            font.getData().setScale(base);
            float lh = font.getLineHeight();
            float y0 = h * .96f, y1 = y0 - lh * 1.35f;
            float badgeH = lh * 2.3f, badgeW = lh * 6.8f, badgeX = w * .025f, badgeTop = y1 - lh * 1.55f;
            hud.end();
            drawKillBadgeShapes(badgeX, badgeTop - badgeH, badgeW, badgeH, lh);
            hud.begin();
            font.setColor(Color.WHITE);
            font.draw(hud,"VIDA  "+hp,w*.025f,y0);
            font.setColor(new Color(.28f,.72f,1f,1f)); font.draw(hud,"COLETE  "+energyVest,w*.025f,y1);
            if (padConnected) {
                font.setColor(new Color(.4f, 1f, .55f, 1f));
                font.draw(hud, "PAD: " + (padName.length() > 18 ? padName.substring(0, 18) + "…" : padName), w * .025f, y1 - font.getLineHeight() * 1.3f);
            }
            font.draw(hud,reloading?"RECARREGANDO...":"MUNIÇÃO  "+ammo+" / "+weaponAmmo[weapon],w*.43f,y0);
            font.setColor(Color.GOLD); font.draw(hud,"$"+money,w*.75f,y0);
            font.setColor(Color.WHITE);
            font.draw(hud,weaponNames[weapon]+(weaponSight[weapon]!=SIGHT_NONE?"  -  "+sightLabel[weaponSight[weapon]]:""),w*.40f,h*.08f);
            // ---- Contador de kills (texto do badge)
            float tx = badgeX + lh * 2.35f;
            font.getData().setScale(base * .62f);
            font.setColor(.75f, .78f, .88f, 1f);
            font.draw(hud, "KILLS", tx, badgeTop - lh * .22f);
            font.getData().setScale(base * 1.7f * (1f + .35f * killPulse));
            font.setColor(1f, MathUtils.lerp(1f, .55f, killPulse), MathUtils.lerp(1f, .55f, killPulse), 1f);
            font.draw(hud, String.valueOf(kills), tx, badgeTop - lh * .62f);
            // ---- Aviso de eliminação ao lado da mira
            if (killFeedT > 0f) {
                float a = MathUtils.clamp(killFeedT / .5f, 0f, 1f);
                float rise = (1.6f - killFeedT) * h * .02f;
                font.getData().setScale(base * 1.05f);
                font.setColor(1f, .35f, .35f, a);
                String msg = "+1 KILL";
                layout.setText(font, msg);
                font.draw(hud, msg, w / 2f - layout.width / 2f, h * .34f + rise);
                font.getData().setScale(base * .85f);
                font.setColor(1f, .84f, .2f, a);
                String rew = "+$" + lastKillReward;
                layout.setText(font, rew);
                font.draw(hud, rew, w / 2f - layout.width / 2f, h * .34f + rise - lh * 1.2f);
            }
            font.setColor(Color.WHITE);
            font.getData().setScale(base);
            hud.end();
            if (reloading) {
                float bx=w*.43f, by=h*.905f, bw=w*.15f, bh=h*.012f*hudScale;
                shapes.begin(ShapeRenderer.ShapeType.Filled);
                shapes.setColor(.25f,.25f,.28f,1f); shapes.rect(bx,by,bw,bh);
                shapes.setColor(1f,.8f,.2f,1f); shapes.rect(bx,by,bw*MathUtils.clamp(reloadTimer/weaponReload[weapon],0f,1f),bh);
                shapes.end();
            }
            if (weaponSight[weapon]!=SIGHT_NONE && adsT>.3f) {
                drawSight(w,h);
            } else {
                shapes.begin(ShapeRenderer.ShapeType.Line);
                shapes.setColor(Color.WHITE);
                float cx=w/2,cy=h/2;
                shapes.line(cx-9,cy,cx-3,cy); shapes.line(cx+3,cy,cx+9,cy);
                shapes.line(cx,cy-9,cx,cy-3); shapes.line(cx,cy+3,cx,cy+9);
                shapes.end();
            }
            if (hitMarkerT > 0f) {
                float cx=w*.5f, cy=h*.5f, a = MathUtils.clamp(hitMarkerT / .12f, 0f, 1f);
                float gap = h * .012f, len = h * (hitMarkerKill ? .024f : .018f), th = Math.max(2f, h * .003f);
                Gdx.gl.glEnable(GL20.GL_BLEND); Gdx.gl.glBlendFunc(GL20.GL_SRC_ALPHA,GL20.GL_ONE_MINUS_SRC_ALPHA);
                shapes.begin(ShapeRenderer.ShapeType.Filled);
                if (hitMarkerKill) shapes.setColor(1f, .15f, .15f, a); else shapes.setColor(1f, 1f, 1f, a);
                for (int sx = -1; sx <= 1; sx += 2) for (int sy = -1; sy <= 1; sy += 2) {
                    shapes.rectLine(cx + sx * gap, cy + sy * gap, cx + sx * (gap + len), cy + sy * (gap + len), th);
                }
                shapes.end(); Gdx.gl.glDisable(GL20.GL_BLEND);
            }
            if (enemyShotIndicator > 0f) {
                float cx=w*.5f, cy=h*.5f;
                float dx=MathUtils.sin(enemyShotAngle-yaw), dy=MathUtils.cos(enemyShotAngle-yaw);
                float ix=cx+dx*w*.34f, iy=cy+dy*h*.34f;
                Gdx.gl.glEnable(GL20.GL_BLEND); Gdx.gl.glBlendFunc(GL20.GL_SRC_ALPHA,GL20.GL_ONE_MINUS_SRC_ALPHA);
                shapes.begin(ShapeRenderer.ShapeType.Filled);
                shapes.setColor(1f,.16f,.12f,Math.min(.85f,enemyShotIndicator));
                shapes.circle(ix,iy,h*.012f);
                shapes.end(); Gdx.gl.glDisable(GL20.GL_BLEND);
            }
            if(mobile) drawTouchControls(w,h);
            return;
        }
        hud.end();
        if(screen==Screen.LAYOUT) drawLayoutEditor(w,h); else drawPanel(w,h);
    }

    private float uiScale(float h) { return Math.max(1f, h / 720f); }

    // Fundo, ícone e destaque do contador de kills (o texto é desenhado pelo drawHud).
    private void drawKillBadgeShapes(float x, float y, float bw, float bh, float lh) {
        Gdx.gl.glEnable(GL20.GL_BLEND);
        Gdx.gl.glBlendFunc(GL20.GL_SRC_ALPHA, GL20.GL_ONE_MINUS_SRC_ALPHA);
        shapes.begin(ShapeRenderer.ShapeType.Filled);
        shapes.setColor(.04f, .04f, .07f, .68f); shapes.rect(x, y, bw, bh);
        if (killPulse > 0f) { shapes.setColor(1f, .2f, .2f, .38f * killPulse); shapes.rect(x, y, bw, bh); }
        shapes.setColor(1f, .28f, .34f, 1f); shapes.rect(x, y, lh * .16f, bh);
        float ix = x + lh * 1.25f, iy = y + bh / 2f, ir = lh * .62f, th = Math.max(2f, lh * .11f);
        shapes.setColor(1f, .28f, .34f, .95f);
        ring(ix, iy, ir, th, 28);
        float g = ir * .35f, e = ir * 1.35f;
        shapes.rectLine(ix - e, iy, ix - g, iy, th); shapes.rectLine(ix + g, iy, ix + e, iy, th);
        shapes.rectLine(ix, iy - e, ix, iy - g, th); shapes.rectLine(ix, iy + g, ix, iy + e, th);
        shapes.end();
        Gdx.gl.glDisable(GL20.GL_BLEND);
    }

    private void layoutTouch(float w,float h) {
        if(!hudCustom) defaultCtl(w,h);
        float sc=hudScale;
        jR=h*.16f*sc; fR=h*.115f*sc; pR=h*.075f*sc; aR=h*.075f*sc; rR=h*.075f*sc; pauseR=h*.055f*sc;
        jX=ctlX[0]*w; jY=ctlY[0]*h; fX=ctlX[1]*w; fY=ctlY[1]*h; pX=ctlX[2]*w; pY=ctlY[2]*h;
        aX=ctlX[3]*w; aY=ctlY[3]*h; rX=ctlX[4]*w; rY=ctlY[4]*h; pauseX=ctlX[5]*w; pauseY=ctlY[5]*h;
        kX=w*.70f; kY=h*.40f; kR=h*.060f*sc;
    }
    private boolean hit(float x,float y,float cx,float cy,float r) {
        float dx=x-cx, dy=y-cy;
        return dx*dx+dy*dy <= r*r*1.3f;
    }
    private void updateStick(float x,float yy) {
        float h=Gdx.graphics.getHeight(), w=Gdx.graphics.getWidth();
        layoutTouch(w,h);
        float dx=(x-jX)/jR, dy=(jY-yy)/jR;
        float len=(float)Math.sqrt(dx*dx+dy*dy);
        if(len>1){dx/=len;dy/=len;}
        moveX=dx; moveY=dy;
    }
    private void centerLabel(String text,float cx,float cy) {
        layout.setText(font,text);
        font.draw(hud,layout,cx-layout.width/2f,cy+layout.height/2f);
    }

    private void drawTouchControls(float w,float h) {
        layoutTouch(w,h);
        Gdx.gl.glEnable(GL20.GL_BLEND);
        Gdx.gl.glBlendFunc(GL20.GL_SRC_ALPHA,GL20.GL_ONE_MINUS_SRC_ALPHA);
        shapes.begin(ShapeRenderer.ShapeType.Filled);
        float kr=jR*.4f;
        shapes.setColor(1,1,1,.12f); shapes.circle(jX,jY,jR);
        shapes.setColor(1,1,1,.35f); shapes.circle(jX+moveX*(jR-kr),jY-moveY*(jR-kr),kr);
        shapes.setColor(1,.28f,.34f,firing?.85f:.55f); shapes.circle(fX,fY,fR);
        shapes.setColor(1,1,1,.22f); shapes.circle(pX,pY,pR);
        shapes.setColor(1,1,1,ads?.50f:.22f); shapes.circle(aX,aY,aR);
        shapes.setColor(1,1,1,.22f); shapes.circle(rX,rY,rR);
        // Botão pause
        shapes.setColor(.9f,.3f,.3f,.55f); shapes.circle(pauseX,pauseY,pauseR);
        shapes.setColor(knifeEquipped?.95f:.9f,.72f,.24f,.62f); shapes.circle(kX,kY,kR);
        shapes.end();
        hud.begin();
        float sx=font.getData().scaleX, sy=font.getData().scaleY;
        font.getData().setScale(h/720f*hudScale);
        font.setColor(Color.WHITE);
        centerLabel("TIRO",fX,fY); centerLabel("PULAR",pX,pY);
        centerLabel("SEGURE",aX,aY); centerLabel("R",rX,rY); centerLabel("FACA",kX,kY);
        font.getData().setScale(h/900f*hudScale);
        centerLabel("||",pauseX,pauseY);
        font.getData().setScale(sx,sy);
        hud.end();
        Gdx.gl.glDisable(GL20.GL_BLEND);
    }

    private void drawTouchPointers() {
        float h=Gdx.graphics.getHeight();
        Gdx.gl.glEnable(GL20.GL_BLEND);
        Gdx.gl.glBlendFunc(GL20.GL_SRC_ALPHA,GL20.GL_ONE_MINUS_SRC_ALPHA);
        shapes.begin(ShapeRenderer.ShapeType.Filled);
        shapes.setColor(1,1,1,.55f);
        for(int i=0;i<5;i++) {
            if(Gdx.input.isTouched(i)) shapes.circle(Gdx.input.getX(i),h-Gdx.input.getY(i),h*.045f);
        }
        shapes.end();
        Gdx.gl.glDisable(GL20.GL_BLEND);
    }

    private void drawButton(float x, float y, float bw, float bh, Color bg, Color border) {
        shapes.setColor(border);
        shapes.rect(x - 2, y - 2, bw + 4, bh + 4);
        shapes.setColor(bg);
        shapes.rect(x, y, bw, bh);
    }

    // Texto centralizado (horizontal e vertical) dentro de um botão; reduz a fonte se não couber.
    private void buttonLabel(String text, float x, float y, float bw, float bh) {
        float sx = font.getData().scaleX, sy = font.getData().scaleY;
        layout.setText(font, text);
        float fit = (bw * .88f) / layout.width;
        if (fit < 1f) { font.getData().setScale(sx * fit, sy * fit); layout.setText(font, text); }
        font.draw(hud, layout, x + bw / 2f - layout.width / 2f, y + bh / 2f + layout.height / 2f);
        font.getData().setScale(sx, sy);
    }
    // Texto centralizado horizontalmente em cx, com o topo em y.
    private void drawCenteredAt(String s, float cx, float y) {
        layout.setText(font, s);
        font.draw(hud, layout, cx - layout.width / 2f, y);
    }

    private void drawLobbyUi(float w, float h) {
        float ui = uiScale(h);
        Gdx.gl.glEnable(GL20.GL_BLEND);
        Gdx.gl.glBlendFunc(GL20.GL_SRC_ALPHA, GL20.GL_ONE_MINUS_SRC_ALPHA);
        shapes.begin(ShapeRenderer.ShapeType.Filled);
        // Faixas escuras translúcidas no topo e na base, para o texto ler bem sobre a cena 3D
        shapes.setColor(0f, 0f, 0f, .38f); shapes.rect(0, h * .87f, w, h * .13f);
        shapes.setColor(0f, 0f, 0f, .38f); shapes.rect(0, 0, w, h * .12f);
        shapes.setColor(1f, .28f, .34f, .9f); shapes.rect(0, h * .87f - 2, w, 3);
        drawButton(w * 0.035f, h * 0.61f, w * 0.34f, h * 0.10f, new Color(0.08f, 0.10f, 0.16f, .92f), new Color(0.38f, 0.48f, 0.62f, 1f)); // card nome
        drawButton(w * 0.70f, h * 0.18f, w * 0.26f, h * 0.16f, new Color(0.10f, 0.52f, 0.27f, 1f), new Color(0.36f, 0.92f, 0.48f, 1f)); // JOGAR
        drawButton(w * 0.035f, h * 0.43f, w * 0.22f, h * 0.075f, new Color(0.18f, 0.22f, 0.34f, 1f), new Color(0.4f, 0.5f, 0.75f, 1f)); // LOJA
        drawButton(w * 0.035f, h * 0.33f, w * 0.22f, h * 0.075f, new Color(0.28f, 0.22f, 0.15f, 1f), new Color(0.55f, 0.45f, 0.25f, 1f)); // NOME
        shapes.end();
        Gdx.gl.glDisable(GL20.GL_BLEND);

        hud.begin();
        font.getData().setScale(2.2f * ui);
        font.setColor(red);
        drawCenteredAt("STRIKE ARENA", w / 2f, h * .975f);
        font.getData().setScale(1.0f * ui);
        font.setColor(.7f, .75f, .9f, 1f);
        drawCenteredAt("LOBBY  -  ARENA", w / 2f, h * .905f);

        font.getData().setScale(.72f * ui);
        font.setColor(.6f, .7f, .85f, 1f);
        layout.setText(font, "JOGADOR");
        font.draw(hud, layout, w * .035f + w * .012f, h * .61f + h * .10f - h * .012f);
        font.getData().setScale(1.15f * ui);
        font.setColor(Color.WHITE);
        String displayName = typingName ? nameBuilder.toString() + "_" : playerName;
        if (displayName.isEmpty()) displayName = "Digite seu nome...";
        buttonLabel(displayName, w * 0.035f, h * 0.61f, w * 0.34f, h * 0.075f);
        font.getData().setScale(1.5f * ui);
        buttonLabel("JOGAR", w * 0.70f, h * 0.18f, w * 0.26f, h * 0.16f);
        font.getData().setScale(1.15f * ui);
        buttonLabel("LOJA", w * 0.035f, h * 0.43f, w * 0.22f, h * 0.075f);
        buttonLabel(typingName ? "CONFIRMAR NOME" : "MUDAR NOME", w * 0.035f, h * 0.33f, w * 0.22f, h * 0.075f);
        font.getData().setScale(.8f * ui);
        font.setColor(Color.LIGHT_GRAY);
        drawCenteredAt("Arraste para girar o personagem  -  personagem salvo neste dispositivo", w / 2f, h * .075f);
        font.getData().setScale(1.15f * ui);
        hud.end();
    }

    private void drawPanel(float w, float h) {
        if (lobbyScene() && screen == Screen.MENU) { drawLobbyUi(w, h); return; }
        float ui = uiScale(h);
        Gdx.gl.glEnable(GL20.GL_BLEND);
        Gdx.gl.glBlendFunc(GL20.GL_SRC_ALPHA, GL20.GL_ONE_MINUS_SRC_ALPHA);
        shapes.begin(ShapeRenderer.ShapeType.Filled);
        // Fundo escuro translúcido (deixa o jogo/lobby visível atrás)
        shapes.setColor(0, 0, 0, 0.78f);
        shapes.rect(0, 0, w, h);
        // Painel central
        shapes.setColor(0.06f, 0.06f, 0.10f, 0.95f);
        shapes.rect(w * 0.22f, h * 0.12f, w * 0.56f, h * 0.76f);
        // Borda sutil
        shapes.setColor(0.25f, 0.25f, 0.35f, 0.6f);
        shapes.rect(w * 0.22f, h * 0.12f, w * 0.56f, 3);
        shapes.rect(w * 0.22f, h * 0.88f - 3, w * 0.56f, 3);

        float btnW = w * 0.38f;
        float btnH = h * 0.075f;
        float btnX = w * 0.31f;

        if (screen == Screen.DEAD) {
            float[] dys = {0.52f, 0.40f, 0.28f, 0.16f};
            Color[] bgs = {
                new Color(0.12f, 0.42f, 0.55f, 1f), new Color(0.15f, 0.45f, 0.25f, 1f),
                new Color(0.25f, 0.28f, 0.45f, 1f), new Color(0.35f, 0.18f, 0.18f, 1f)
            };
            for (int i = 0; i < 4; i++) {
                Color border = (menuIndex == i) ? new Color(1f, 0.9f, 0.3f, 1f) : new Color(0.4f, 0.45f, 0.6f, 1f);
                drawButton(btnX, h * dys[i], btnW, btnH, bgs[i], border);
            }
        } else if (screen == Screen.PAUSED) {
            float[] pys = {0.56f, 0.46f, 0.36f, 0.26f};
            Color[] pbg = {
                new Color(0.15f, 0.45f, 0.25f, 1f), new Color(0.25f, 0.28f, 0.45f, 1f),
                new Color(0.30f, 0.25f, 0.10f, 1f), new Color(0.35f, 0.18f, 0.18f, 1f)
            };
            for (int i = 0; i < 4; i++) {
                Color border = (menuIndex == i) ? new Color(1f, 0.9f, 0.3f, 1f) : new Color(0.4f, 0.45f, 0.6f, 1f);
                drawButton(btnX, h * pys[i], btnW, btnH, pbg[i], border);
            }

            // Barra de sensibilidade
            float barX = w * 0.30f;
            float barW = w * 0.40f;
            float barY = h * 0.17f;
            float barH = h * 0.032f;
            float t = MathUtils.clamp((sens - sensMin) / (sensMax - sensMin), 0f, 1f);
            float knobX = barX + t * barW;
            shapes.setColor(0.12f, 0.12f, 0.18f, 1f);
            shapes.rect(barX, barY, barW, barH);
            shapes.setColor(0.85f, 0.25f, 0.30f, 1f);
            shapes.rect(barX, barY, t * barW, barH);
            shapes.setColor(1f, 1f, 1f, 1f);
            shapes.circle(knobX, barY + barH * 0.5f, barH * 0.9f);
        } else if (screen == Screen.SHOP) {
            for (int i = 0; i < weaponNames.length; i++) {
                float by = h * (0.58f - i * 0.085f);
                Color bg = weaponOwned[i] ? (weapon == i ? new Color(0.15f, 0.4f, 0.25f, 1f) : new Color(0.18f, 0.18f, 0.25f, 1f))
                        : new Color(0.22f, 0.18f, 0.15f, 1f);
                drawButton(w * 0.28f, by, w * 0.44f, h * 0.07f, bg, new Color(0.4f, 0.4f, 0.5f, 0.8f));
                shapes.setColor(0.5f, 0.55f, 0.65f, 1f);
                shapes.rect(w * 0.30f, by + h * 0.018f, w * 0.045f, h * 0.035f);
            }
            drawButton(btnX, h * 0.14f, btnW, btnH * 0.85f, new Color(0.3f, 0.15f, 0.15f, 1f), new Color(0.55f, 0.25f, 0.25f, 1f));
        }
        shapes.end();
        Gdx.gl.glDisable(GL20.GL_BLEND);

        // Textos
        hud.begin();
        font.setColor(red);
        String title = screen == Screen.PAUSED ? "PAUSADO" : screen == Screen.SHOP ? "LOJA" : "VOCÊ MORREU";
        font.getData().setScale(2.2f * ui);
        drawCenteredAt(title, w / 2f, h * 0.84f);
        font.getData().setScale(1.15f * ui);

        if (screen == Screen.DEAD) {
            font.setColor(Color.GOLD);
            font.getData().setScale(1.5f * ui);
            drawCenteredAt("KILLS: " + kills + "     $ " + money, w / 2f, h * 0.70f);
            font.getData().setScale(1.15f * ui);
            font.setColor(Color.WHITE);
            buttonLabel("RESPAWN AQUI", btnX, h * 0.52f, btnW, btnH);
            buttonLabel("JOGAR NOVAMENTE", btnX, h * 0.40f, btnW, btnH);
            buttonLabel("LOJA", btnX, h * 0.28f, btnW, btnH);
            buttonLabel("MENU PRINCIPAL", btnX, h * 0.16f, btnW, btnH);
        } else if (screen == Screen.PAUSED) {
            font.setColor(Color.WHITE);
            buttonLabel("CONTINUAR", btnX, h * 0.56f, btnW, btnH);
            buttonLabel("LOJA", btnX, h * 0.46f, btnW, btnH);
            buttonLabel("PERSONALIZAR HUD", btnX, h * 0.36f, btnW, btnH);
            buttonLabel("MENU", btnX, h * 0.26f, btnW, btnH);
            font.setColor(Color.LIGHT_GRAY);
            drawCenteredAt("SENS: " + String.format(Locale.US, "%.1f", sens), w / 2f, h * 0.145f);
        } else if (screen == Screen.SHOP) {
            font.setColor(Color.GOLD);
            drawCenteredAt("SALDO: $" + money, w / 2f, h * 0.73f);
            for (int i = 0; i < weaponNames.length; i++) {
                float by = h * (0.58f - i * 0.085f);
                String state = weaponOwned[i] ? (weapon == i ? "EQUIPADA" : "POSSUI") : "$" + weaponPrice[i];
                String icon = i == 0 ? "[P]" : i == 1 ? "[S]" : i == 2 ? "[R]" : i == 3 ? "[G]" : "[N]";
                float cy = by + h * 0.035f;
                font.setColor(Color.WHITE);
                layout.setText(font, icon + "  " + weaponNames[i]);
                font.draw(hud, layout, w * 0.365f, cy + layout.height / 2f);
                font.setColor(weaponOwned[i] ? (weapon == i ? new Color(.45f, 1f, .55f, 1f) : Color.LIGHT_GRAY) : Color.GOLD);
                layout.setText(font, state);
                font.draw(hud, layout, w * 0.70f - layout.width, cy + layout.height / 2f);
            }
            font.setColor(Color.WHITE);
            buttonLabel("VOLTAR", btnX, h * 0.14f, btnW, btnH * 0.85f);
        }
        font.getData().setScale(1.15f * ui);
        hud.end();
    }
    private void openShop() { if (screen != Screen.SHOP) shopReturn = screen; screen=Screen.SHOP; unlockMouse(); menuIndex = 0; }
    private void closeShop() { screen = (shopReturn == Screen.SHOP || shopReturn == Screen.PLAYING) ? Screen.MENU : shopReturn; }
    private void commitName() {
        if (nameBuilder.length() > 0) playerName = nameBuilder.toString();
        if (prefs != null) prefs.putString("playerName", playerName).flush();
        typingName = false;
    }
    private void buyWeapon(int i) {
        if(i<0||i>=weaponNames.length)return;
        if(weaponOwned[i]) { weapon=i; ammo=weaponAmmo[i]; reloading=false; }
        else if(money>=weaponPrice[i]) { money-=weaponPrice[i]; weaponOwned[i]=true; weapon=i; ammo=weaponAmmo[i]; reloading=false; }
    }
    private void buySight(int i) {
        if(i<0||i>=sightNames.length)return;
        if(sightOwned[i]) sight=i;
        else if(money>=sightPrice[i]) {money-=sightPrice[i];sightOwned[i]=true;sight=i;}
    }

    @Override public boolean keyDown(int key) {
        // Digitando o nome: teclas de atalho (L, R, V, WASD...) não devem agir.
        if (typingName && screen == Screen.MENU) {
            if (key == Input.Keys.ENTER) commitName();
            else if (key == Input.Keys.ESCAPE) typingName = false;
            return false;
        }
        if(key==Input.Keys.W)moveForward=true; if(key==Input.Keys.S)moveBack=true;
        if(key==Input.Keys.A)moveLeft=true; if(key==Input.Keys.D)moveRight=true;
        if(key==Input.Keys.SPACE)jumpRequested=true;
        if(key==Input.Keys.R && screen==Screen.PLAYING)startReload();
        if(key==Input.Keys.V && screen==Screen.PLAYING) knifeEquipped = !knifeEquipped;
        if(key==Input.Keys.ESCAPE || key==Input.Keys.BACK) {
            if(screen==Screen.PLAYING){screen=Screen.PAUSED;unlockMouse();}
            else if(screen==Screen.PAUSED){screen=Screen.MENU;}
            else if(screen==Screen.SHOP){closeShop();}
            else if(screen==Screen.DEAD){screen=Screen.MENU;}
            else if(screen==Screen.LAYOUT){saveHudPrefs();screen=Screen.PAUSED;}
        }
        if(key==Input.Keys.ENTER) {
            if(screen==Screen.DEAD) { respawnHere(); }
            else if(screen==Screen.MENU) startGame();
            else if(screen==Screen.PAUSED){screen=Screen.PLAYING;lockMouse();}
        }
        if(key==Input.Keys.L && (screen==Screen.MENU||screen==Screen.PAUSED||screen==Screen.DEAD))openShop();
        if(key==Input.Keys.Q && screen==Screen.SHOP)closeShop();
        if(screen==Screen.SHOP && key>=Input.Keys.NUM_1 && key<=Input.Keys.NUM_5)buyWeapon(key-Input.Keys.NUM_1);
        if(key==Input.Keys.TAB && screen==Screen.PLAYING)ads=!ads;
        return false;
    }
    @Override public boolean keyUp(int key) {
        if(key==Input.Keys.W)moveForward=false; if(key==Input.Keys.S)moveBack=false;
        if(key==Input.Keys.A)moveLeft=false; if(key==Input.Keys.D)moveRight=false;
        return false;
    }
    @Override public boolean touchDown(int x, int y, int pointer, int button) {
        float w = Gdx.graphics.getWidth(), h = Gdx.graphics.getHeight();
        float yy = h - y;
        if (screen == Screen.LAYOUT) return layoutEditorTouch(x, yy);
        float btnW = w * 0.38f;
        float btnH = h * 0.075f;
        float btnX = w * 0.31f;

        // ===== MENU PRINCIPAL (Lobby) =====
        if (screen == Screen.MENU) {
            // JOGAR
            if (x >= w*.70f && x <= w*.96f && yy >= h*.18f && yy <= h*.34f) {
                if (typingName) commitName();
                startGame();
                return true;
            }
            // LOJA
            if (x >= w*.035f && x <= w*.255f && yy >= h*.43f && yy <= h*.505f) {
                openShop();
                return true;
            }
            // MUDAR / CONFIRMAR NOME
            if (x >= w*.035f && x <= w*.255f && yy >= h*.33f && yy <= h*.405f) {
                if (typingName) {
                    commitName();
                } else if (mobile) {
                    // Usa o teclado nativo do Android somente ao tocar em MUDAR NOME.
                    Gdx.input.getTextInput(new Input.TextInputListener() {
                        @Override public void input(String text) {
                            if (text != null && !text.trim().isEmpty()) {
                                String clean = text.trim();
                                playerName = clean.substring(0, Math.min(12, clean.length()));
                                if (prefs != null) prefs.putString("playerName", playerName).flush();
                            }
                        }
                        @Override public void canceled() { }
                    }, "Mudar nome", playerName, "Digite seu nome");
                } else {
                    typingName = true;
                    nameBuilder.setLength(0);
                    nameBuilder.append(playerName);
                }
                return true;
            }
            // Toque/arraste fora dos botões: gira o personagem do lobby
            draggingLobby = true; lobbyDragX = x;
            return true;
        }

        // ===== TELA DE MORTE =====
        if (screen == Screen.DEAD) {
            // RESPAWN AQUI (mesmo lugar)
            if (x >= btnX && x <= btnX + btnW && yy >= h * 0.52f && yy <= h * 0.52f + btnH) {
                respawnHere();
                return true;
            }
            // JOGAR NOVAMENTE (mapa limpo)
            if (x >= btnX && x <= btnX + btnW && yy >= h * 0.40f && yy <= h * 0.40f + btnH) {
                startGame();
                return true;
            }
            if (x >= btnX && x <= btnX + btnW && yy >= h * 0.28f && yy <= h * 0.28f + btnH) {
                openShop();
                return true;
            }
            if (x >= btnX && x <= btnX + btnW && yy >= h * 0.16f && yy <= h * 0.16f + btnH) {
                screen = Screen.MENU;
                return true;
            }
            return true; // não inicia clicando fora
        }

        // ===== PAUSE =====
        if (screen == Screen.PAUSED) {
            // Barra de sensibilidade
            float barX = w * 0.30f;
            float barW = w * 0.40f;
            float barY = h * 0.17f;
            float barH = h * 0.032f;
            float pad = barH * 2f;
            if (x >= barX - pad && x <= barX + barW + pad && yy >= barY - pad && yy <= barY + barH + pad) {
                draggingSens = true;
                float t = MathUtils.clamp((x - barX) / barW, 0f, 1f);
                sens = sensMin + t * (sensMax - sensMin);
                return true;
            }
            // CONTINUAR
            if (x >= btnX && x <= btnX + btnW && yy >= h * 0.56f && yy <= h * 0.56f + btnH) {
                screen = Screen.PLAYING;
                lockMouse();
                return true;
            }
            // LOJA
            if (x >= btnX && x <= btnX + btnW && yy >= h * 0.46f && yy <= h * 0.46f + btnH) {
                openShop();
                return true;
            }
            // PERSONALIZAR HUD
            if (x >= btnX && x <= btnX + btnW && yy >= h * 0.36f && yy <= h * 0.36f + btnH) {
                screen = Screen.LAYOUT;
                return true;
            }
            // MENU
            if (x >= btnX && x <= btnX + btnW && yy >= h * 0.26f && yy <= h * 0.26f + btnH) {
                screen = Screen.MENU;
                return true;
            }
            return true;
        }

        // ===== LOJA =====
        if (screen == Screen.SHOP) {
            // Botões de armas
            for (int i = 0; i < weaponNames.length; i++) {
                float by = h * (0.58f - i * 0.085f);
                if (x >= w * 0.28f && x <= w * 0.72f && yy >= by && yy <= by + h * 0.07f) {
                    buyWeapon(i);
                    return true;
                }
            }
            // VOLTAR
            if (x >= btnX && x <= btnX + btnW && yy >= h * 0.14f && yy <= h * 0.14f + btnH * 0.85f) {
                closeShop();
                return true;
            }
            return true;
        }

        // ===== JOGO =====
        if (mobile) {
            layoutTouch(w, h);
            if (hit(x, yy, pauseX, pauseY, pauseR)) {
                screen = Screen.PAUSED;
                unlockMouse();
                return true;
            }
            if (hit(x, yy, fX, fY, fR)) { firePointer = pointer; firing = true; fire(); }
            else if (hit(x, yy, pX, pY, pR)) { jumpRequested = true; }
            else if (hit(x, yy, aX, aY, aR)) { aimPointer = pointer; ads = true; }
            else if (hit(x, yy, kX, kY, kR)) { knifeEquipped = !knifeEquipped; ads = false; }
            else if (hit(x, yy, rX, rY, rR)) { startReload(); }
            else if (hit(x, yy, jX, jY, jR * 1.7f)) { movePointer = pointer; updateStick(x, yy); }
            else { lookPointer = pointer; touchStartX = x; touchStartY = y; }
        } else {
            if (button == Input.Buttons.LEFT) fire();
            if (button == Input.Buttons.RIGHT) ads = true;
        }
        return true;
    }
    @Override public boolean touchUp(int x,int y,int pointer,int button) {
        if(pointer==movePointer){movePointer=-1;moveX=moveY=0;}
        if(pointer==lookPointer)lookPointer=-1;
        if(pointer==firePointer){firePointer=-1;firing=false;}
        if(pointer==aimPointer){aimPointer=-1;ads=false;}
        draggingSens = false; draggingLobby = false;
        if(screen==Screen.LAYOUT){ layoutDrag=-1; draggingHudScale=false; saveHudPrefs(); }
        if(!mobile && button==Input.Buttons.RIGHT) ads=false;
        return true;
    }
    @Override public boolean touchDragged(int x,int y,int pointer) {
        if (screen == Screen.LAYOUT) { layoutEditorDrag(x, Gdx.graphics.getHeight() - y); return true; }
        if (draggingLobby && screen == Screen.MENU) {
            lobbyYaw += (x - lobbyDragX) * .6f; lobbyDragX = x;
            return true;
        }
        if (!mobile && screen == Screen.PLAYING) { desktopLook(); return true; }   // olhar enquanto o botão do mouse está pressionado
        if (draggingSens && screen == Screen.PAUSED) {
            float w = Gdx.graphics.getWidth();
            float barX = w * 0.30f;   // mesma geometria usada no desenho e no toque
            float barW = w * 0.40f;
            float t = MathUtils.clamp((x - barX) / barW, 0f, 1f);
            sens = sensMin + t * (sensMax - sensMin);
            return true;
        }
        if(mobile) {
            if(pointer==movePointer) {
                updateStick(x,Gdx.graphics.getHeight()-y);
            } else if(pointer==lookPointer) {
                lookX+=x-touchStartX; lookY+=y-touchStartY; touchStartX=x; touchStartY=y;
            }
        }
        return true;
    }
    private void desktopLook() {
        if(!mobile&&screen==Screen.PLAYING&&Gdx.input.isCursorCatched()) {
            float fs = MathUtils.clamp(camera.fieldOfView/75f,.2f,1f);
            yaw -= Gdx.input.getDeltaX()*.0022f*sens*fs;  // corrige eixo X invertido
            pitch -= Gdx.input.getDeltaY()*.0022f*sens*fs;
        }
    }
    @Override public boolean mouseMoved(int x,int y) {
        desktopLook();
        return false;
    }
    @Override public boolean scrolled(float amountX,float amountY){return false;}
    @Override public boolean touchCancelled(int x,int y,int pointer,int button){return touchUp(x,y,pointer,button);}
    @Override public boolean keyTyped(char c) {
        if (typingName && screen == Screen.MENU) {
            if (c == 8 || c == 127) { // backspace
                if (nameBuilder.length() > 0) nameBuilder.deleteCharAt(nameBuilder.length() - 1);
            } else if (c >= 32 && c < 127 && nameBuilder.length() < 12) {
                nameBuilder.append(c);
            }
            return true;
        }
        return false;
    }

    @Override public void resize(int width,int height) {
        if(camera!=null){camera.viewportWidth=width;camera.viewportHeight=height;camera.update();}
        if(shapes!=null){shapes.getProjectionMatrix().setToOrtho2D(0,0,width,height);shapes.updateMatrices();}
        if(hud!=null){hud.getProjectionMatrix().setToOrtho2D(0,0,width,height);hud.setProjectionMatrix(hud.getProjectionMatrix());}
    }
    @Override public void dispose() {
        modelBatch.dispose(); hud.dispose(); shapes.dispose(); font.dispose();
        for (Model m : generatedWorldModels) m.dispose();
        if (floorModel != null) floorModel.dispose();
        if (wallModel != null) wallModel.dispose();
        if (crateModel != null) crateModel.dispose();
        if (houseModel != null) houseModel.dispose();
        if (roofModel != null) roofModel.dispose();
        if (enemyBodyModel != null) enemyBodyModel.dispose();
        if (enemyHeadModel != null) enemyHeadModel.dispose();
        if (gunModel != null) gunModel.dispose();
        if (pickupModel != null) pickupModel.dispose();
        if (moneyChestModel != null) moneyChestModel.dispose();
        if (enemyGunModel != null) enemyGunModel.dispose();
        if (knifeBladeModel != null) knifeBladeModel.dispose();
        if (knifeHandleModel != null) knifeHandleModel.dispose();
        if (gunTexture != null) gunTexture.dispose();
        if (grassTexture != null) grassTexture.dispose();
        for (Model m : charModels) m.dispose();
        for (Model m : gunModels) m.dispose();
        if (scopeTex != null) scopeTex.dispose();
        for (Texture t : charTextures) t.dispose();
        if (ambientMusic != null) ambientMusic.dispose();
        if (sfxShoot != null) sfxShoot.dispose();
        if (sfxHit != null) sfxHit.dispose();
        if (sfxReload != null) sfxReload.dispose();
    }
}
