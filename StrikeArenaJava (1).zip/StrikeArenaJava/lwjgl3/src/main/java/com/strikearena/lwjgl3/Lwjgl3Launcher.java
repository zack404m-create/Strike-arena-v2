package com.strikearena.lwjgl3;

import com.badlogic.gdx.backends.lwjgl3.Lwjgl3Application;
import com.badlogic.gdx.backends.lwjgl3.Lwjgl3ApplicationConfiguration;
import com.strikearena.StrikeArenaGame;

public class Lwjgl3Launcher {
    public static void main(String[] args) {
        Lwjgl3ApplicationConfiguration config = new Lwjgl3ApplicationConfiguration();
        config.setTitle("Strike Arena");
        config.setWindowedMode(1280, 720);
        config.setForegroundFPS(120);
        config.useVsync(true);
        new Lwjgl3Application(new StrikeArenaGame(), config);
    }
}
