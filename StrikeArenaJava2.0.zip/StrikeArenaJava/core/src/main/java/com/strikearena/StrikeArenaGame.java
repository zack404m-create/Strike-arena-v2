package com.strikearena;

import com.badlogic.gdx.*;
import com.badlogic.gdx.graphics.*;
import com.badlogic.gdx.graphics.g2d.*;
import com.badlogic.gdx.graphics.g3d.loader.ObjLoader;
import com.badlogic.gdx.graphics.g3d.attributes.TextureAttribute;
import com.badlogic.gdx.graphics.g3d.*;
import com.badlogic.gdx.graphics.g3d.attributes.ColorAttribute;
import com.badlogic.gdx.graphics.g3d.attributes.BlendingAttribute;
import com.badlogic.gdx.graphics.g3d.environment.DirectionalLight;
import com.badlogic.gdx.graphics.g3d.utils.*;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.math.*;
import com.badlogic.gdx.utils.*;

import java.util.*;

/**
 * Strike Arena - port Java/LibGDX do protótipo HTML enviado.
 * Código-base jogável para desktop e Android.
 */
public class StrikeArenaGame extends ApplicationAdapter implements InputProcessor {
    private enum Screen { MENU, PLAYING, PAUSED, SHOP, DEAD }
    private Screen screen = Screen.MENU;

    private PerspectiveCamera camera;
    private ModelBatch modelBatch;
    private ModelBuilder modelBuilder;
    private Environment environment;
    private Model floorModel, wallModel, crateModel, enemyBodyModel, enemyHeadModel, gunModel, pickupModel;
    private Texture gunTexture;
    private final Array<ModelInstance> staticWorld = new Array<>();
    private final Array<Enemy> enemies = new Array<>();
    private final Array<Pickup> pickups = new Array<>();
    private final Vector3 velocity = new Vector3();
    private final Vector3 tmp = new Vector3();
    private final Vector3 forward = new Vector3();
    private final Vector3 right = new Vector3();
    private final Vector3 move = new Vector3();
    private final Vector3 gunOffset = new Vector3(.28f, -.25f, -.55f);

    private BitmapFont font;
    private SpriteBatch hud;
    private ShapeRenderer shapes;
    private final Color red = new Color(1f, .28f, .34f, 1);
    private final Color dark = new Color(.025f, .025f, .05f, 1);

    private final String[] weaponNames = {"Pistola", "SMG", "Rifle", "Shotgun", "Sniper"};
    private final int[] weaponDamage = {28, 17, 36, 52, 90};
    private final float[] weaponRate = {.18f, .07f, .13f, .5f, .9f};
    private final int[] weaponAmmo = {12, 32, 28, 6, 5};
    private final int[] weaponPrice = {0, 400, 700, 900, 1500};
    private final boolean[] weaponOwned = {true, false, false, false, false};
    private final String[] sightNames = {"Padrão", "Red Dot", "Holo", "ACOG"};
    private final int[] sightPrice = {0, 250, 500, 800};
    private final boolean[] sightOwned = {true, false, false, false};

    private int weapon = 0, ammo = 12, sight = 0, kills = 0, money = 0, hp = 100;
    private float spawnTimer = 0, lastShot = -10, lastDamage = 0, regenTimer = 0;
    private float yaw = 0, pitch = 0, sens = 1f, volume = .7f;
    private boolean aimAssist = true, ads = false, firing = false, moveForward, moveBack, moveLeft, moveRight;
    private boolean jumpRequested = false, mobile = false;
    private int lookPointer = -1, movePointer = -1, firePointer = -1;
    private float jX, jY, jR, fX, fY, fR, pX, pY, pR, aX, aY, aR, rX, rY, rR, pauseX, pauseY, pauseR;
    private boolean draggingSens = false;
    private float sensMin = 0.3f, sensMax = 2.5f;
    private final GlyphLayout layout = new GlyphLayout();
    private float lookX, lookY, moveX, moveY, touchStartX, touchStartY;
    private float worldTime = 0;
    private final Random random = new Random();
    private static final String[] CHAR_IDS = {"g", "h", "l", "r"};
    private static final float CHAR_SCALE = .62f;
    private final Array<Model> charModels = new Array<>();
    private final Array<Texture> charTextures = new Array<>();

    // ===== Armas 3D procedurais + miras =====
    private static final int SIGHT_NONE = 0, SIGHT_REDDOT = 1, SIGHT_HOLO = 2, SIGHT_PRISM = 3;
    private final int[] weaponSight = {SIGHT_REDDOT, SIGHT_HOLO, SIGHT_NONE, SIGHT_NONE, SIGHT_PRISM};
    private final String[] sightLabel = {"", "Red Dot", "Holografica", "Prismatica"};
    private final float[] weaponAdsFov = {58f, 55f, 48f, 52f, 20f};
    private final float[][] hipOff = {{.13f,-.12f,-.34f},{.15f,-.13f,-.42f},{.20f,-.17f,-.55f},{.20f,-.17f,-.55f},{.17f,-.15f,-.65f}};
    private final float[][] adsOff = {{0f,-.0445f,-.38f},{0f,-.077f,-.42f},{.07f,-.14f,-.55f},{.07f,-.14f,-.55f},{0f,-.073f,-.65f}};
    private static class GunPart { ModelInstance inst; final Matrix4 local = new Matrix4(); }
    private final Array<Array<GunPart>> weaponParts = new Array<>();
    private final Array<Model> gunModels = new Array<>();
    private PerspectiveCamera viewCam;
    private Environment viewEnv;
    private Texture scopeTex;
    private float adsT = 0, kick = 0;
    private final Matrix4 viewBase = new Matrix4();
    private static final Color C_DARK = new Color(.12f,.13f,.15f,1), C_MID = new Color(.23f,.24f,.28f,1),
        C_LIGHT = new Color(.45f,.47f,.53f,1), C_BLACK = new Color(.05f,.05f,.06f,1),
        C_OLIVE = new Color(.22f,.27f,.19f,1), C_ORANGE = new Color(1f,.55f,.10f,1), C_GLASS = new Color(.45f,.75f,1f,1);

    private static class Enemy {
        ModelInstance body, head;
        boolean skinned;
        Vector3 position = new Vector3();
        float hp = 100, speed, attackTimer;
    }
    private static class Pickup {
        ModelInstance model;
        Vector3 position = new Vector3();
        float phase;
    }

    @Override public void create() {
        mobile = Gdx.app.getType() == Application.ApplicationType.Android;
        modelBatch = new ModelBatch();
        modelBuilder = new ModelBuilder();
        hud = new SpriteBatch();
        shapes = new ShapeRenderer();
        font = new BitmapFont();
        font.getData().setScale(1.15f);
        camera = new PerspectiveCamera(75, Gdx.graphics.getWidth(), Gdx.graphics.getHeight());
        camera.position.set(0, 1.7f, 0);
        camera.lookAt(0, 1.7f, -1);
        camera.near = .1f; camera.far = 200; camera.update();
        environment = new Environment();
        environment.set(new ColorAttribute(ColorAttribute.AmbientLight, .48f, .48f, .58f, 1));
        environment.add(new DirectionalLight().set(1f, .88f, .72f, -1, -2, -1));
        buildWorld();
        loadCharacters();
        buildWeaponModels();
        Gdx.input.setInputProcessor(this);
        Gdx.input.setCatchKey(Input.Keys.BACK, true);
    }

    private Material solid(Color c) { return new Material(ColorAttribute.createDiffuse(c)); }
    private void gpAdd(Array<GunPart> l, Model m, float x, float y, float z, float rotX, boolean cyl) {
        gunModels.add(m);
        GunPart p = new GunPart();
        p.inst = new ModelInstance(m);
        p.local.setToTranslation(x, y, z);
        if (cyl) p.local.rotate(Vector3.X, 90f);
        if (rotX != 0f) p.local.rotate(Vector3.X, rotX);
        l.add(p);
    }
    private void gpBox(Array<GunPart> l, float w, float h, float d, float x, float y, float z, float rotX, Color c) {
        gpAdd(l, modelBuilder.createBox(w, h, d, solid(c),
            VertexAttributes.Usage.Position | VertexAttributes.Usage.Normal), x, y, z, rotX, false);
    }
    private void gpCyl(Array<GunPart> l, float dia, float len, float x, float y, float z, Color c) {
        gpAdd(l, modelBuilder.createCylinder(dia, len, dia, 14, solid(c),
            VertexAttributes.Usage.Position | VertexAttributes.Usage.Normal), x, y, z, 0f, true);
    }
    private void gpGlass(Array<GunPart> l, float w, float h, float d, float x, float y, float z, float alpha) {
        Material mat = new Material(ColorAttribute.createDiffuse(C_GLASS), new BlendingAttribute(true, alpha));
        gpAdd(l, modelBuilder.createBox(w, h, d, mat,
            VertexAttributes.Usage.Position | VertexAttributes.Usage.Normal), x, y, z, 0f, false);
    }

    private void buildWeaponModels() {
        for (int i = 0; i < weaponNames.length; i++) weaponParts.add(new Array<GunPart>());
        buildPistol(weaponParts.get(0));
        buildSmg(weaponParts.get(1));
        buildRifle(weaponParts.get(2));
        buildShotgun(weaponParts.get(3));
        buildSniper(weaponParts.get(4));

        viewCam = new PerspectiveCamera(60, Gdx.graphics.getWidth(), Gdx.graphics.getHeight());
        viewCam.position.set(0, 0, 0);
        viewCam.lookAt(0, 0, -1);
        viewCam.up.set(0, 1, 0);
        viewCam.near = .03f; viewCam.far = 4f; viewCam.update();
        viewEnv = new Environment();
        viewEnv.set(new ColorAttribute(ColorAttribute.AmbientLight, .62f, .62f, .68f, 1));
        viewEnv.add(new DirectionalLight().set(1f, .96f, .9f, -.4f, -.8f, -.6f));

        // Mascara circular da luneta (preto fora, transparente no meio)
        int n = 512;
        Pixmap pm = new Pixmap(n, n, Pixmap.Format.RGBA8888);
        pm.setBlending(Pixmap.Blending.None);
        for (int py = 0; py < n; py++) {
            for (int px = 0; px < n; px++) {
                float dx = (px - n / 2f) / (n / 2f), dy = (py - n / 2f) / (n / 2f);
                float d = (float) Math.sqrt(dx * dx + dy * dy);
                float a = d < .88f ? 0f : (d > .91f ? 1f : (d - .88f) / .03f);
                pm.setColor(0f, 0f, 0f, a);
                pm.drawPixel(px, py);
            }
        }
        scopeTex = new Texture(pm);
        scopeTex.setFilter(Texture.TextureFilter.Linear, Texture.TextureFilter.Linear);
        pm.dispose();
    }

    private void buildPistol(Array<GunPart> l) {
        gpBox(l, .034f, .042f, .19f, 0, 0, 0, 0, C_DARK);
        gpCyl(l, .014f, .03f, 0, .003f, -.108f, C_LIGHT);
        gpBox(l, .030f, .024f, .17f, 0, -.033f, .005f, 0, C_MID);
        gpBox(l, .032f, .095f, .046f, 0, -.090f, .062f, -12f, C_BLACK);
        gpBox(l, .008f, .004f, .05f, 0, -.060f, -.03f, 0, C_MID);
        gpBox(l, .006f, .022f, .008f, 0, -.052f, -.004f, 10f, C_LIGHT);
        gpBox(l, .012f, .008f, .012f, 0, .0245f, -.085f, 0, C_BLACK);
        // Red dot
        gpBox(l, .034f, .006f, .052f, 0, .024f, .040f, 0, C_BLACK);
        gpBox(l, .004f, .034f, .052f, -.0145f, .044f, .040f, 0, C_BLACK);
        gpBox(l, .004f, .034f, .052f, .0145f, .044f, .040f, 0, C_BLACK);
        gpBox(l, .033f, .006f, .052f, 0, .064f, .040f, 0, C_BLACK);
        gpBox(l, .010f, .008f, .010f, 0, .034f, .020f, 0, C_DARK);
        gpGlass(l, .025f, .026f, .002f, 0, .0445f, .052f, .22f);
    }

    private void buildSmg(Array<GunPart> l) {
        gpBox(l, .046f, .062f, .22f, 0, 0, .02f, 0, C_DARK);
        gpBox(l, .042f, .048f, .15f, 0, -.004f, -.165f, 0, C_MID);
        gpCyl(l, .016f, .12f, 0, .004f, -.30f, C_LIGHT);
        gpCyl(l, .032f, .14f, 0, .004f, -.35f, C_BLACK);
        gpBox(l, .030f, .050f, .14f, 0, -.012f, .215f, 0, C_BLACK);
        gpBox(l, .034f, .070f, .02f, 0, -.012f, .29f, 0, C_BLACK);
        gpBox(l, .034f, .10f, .05f, 0, -.085f, .06f, -14f, C_BLACK);
        gpBox(l, .028f, .12f, .05f, 0, -.100f, -.045f, 6f, C_DARK);
        gpBox(l, .030f, .065f, .036f, 0, -.062f, -.16f, 0, C_BLACK);
        gpBox(l, .020f, .008f, .22f, 0, .035f, .02f, 0, C_LIGHT);
        // Holografica
        gpBox(l, .044f, .012f, .075f, 0, .045f, .01f, 0, C_BLACK);
        gpBox(l, .006f, .050f, .075f, -.029f, .076f, .01f, 0, C_BLACK);
        gpBox(l, .006f, .050f, .075f, .029f, .076f, .01f, 0, C_BLACK);
        gpBox(l, .064f, .008f, .075f, 0, .105f, .01f, 0, C_BLACK);
        gpBox(l, .050f, .018f, .022f, 0, .062f, -.035f, 0, C_DARK);
        gpGlass(l, .052f, .046f, .002f, 0, .077f, .040f, .20f);
    }

    private void buildRifle(Array<GunPart> l) {
        gpBox(l, .05f, .06f, .30f, 0, 0, .02f, 0, C_DARK);
        gpCyl(l, .02f, .35f, 0, .004f, -.325f, C_LIGHT);
        gpBox(l, .05f, .05f, .20f, 0, -.004f, -.20f, 0, C_MID);
        gpBox(l, .04f, .07f, .22f, 0, -.02f, .27f, 0, C_OLIVE);
        gpBox(l, .034f, .095f, .045f, 0, -.08f, .08f, -14f, C_BLACK);
        gpBox(l, .028f, .11f, .05f, 0, -.095f, -.02f, 8f, C_DARK);
        gpBox(l, .006f, .03f, .006f, 0, .045f, -.28f, 0, C_BLACK);
        gpBox(l, .02f, .02f, .012f, 0, .04f, .12f, 0, C_BLACK);
    }

    private void buildShotgun(Array<GunPart> l) {
        gpBox(l, .05f, .06f, .22f, 0, 0, .04f, 0, C_DARK);
        gpCyl(l, .03f, .50f, 0, .012f, -.38f, C_MID);
        gpCyl(l, .026f, .42f, 0, -.028f, -.34f, C_LIGHT);
        gpBox(l, .05f, .04f, .12f, 0, -.03f, -.30f, 0, C_OLIVE);
        gpBox(l, .04f, .075f, .26f, 0, -.02f, .24f, 0, C_OLIVE);
        gpBox(l, .034f, .09f, .042f, 0, -.07f, .09f, -14f, C_BLACK);
        gpBox(l, .008f, .012f, .008f, 0, .03f, -.62f, 0, C_ORANGE);
    }

    private void buildSniper(Array<GunPart> l) {
        gpBox(l, .044f, .054f, .28f, 0, 0, .04f, 0, C_DARK);
        gpCyl(l, .022f, .55f, 0, .004f, -.40f, C_LIGHT);
        gpCyl(l, .030f, .07f, 0, .004f, -.70f, C_BLACK);
        gpBox(l, .046f, .050f, .24f, 0, -.008f, -.17f, 0, C_OLIVE);
        gpBox(l, .040f, .070f, .30f, 0, -.022f, .36f, 0, C_OLIVE);
        gpBox(l, .034f, .028f, .15f, 0, .034f, .37f, 0, C_OLIVE);
        gpBox(l, .042f, .092f, .022f, 0, -.024f, .52f, 0, C_BLACK);
        gpBox(l, .034f, .095f, .042f, 0, -.075f, .17f, -16f, C_BLACK);
        gpBox(l, .028f, .070f, .05f, 0, -.060f, .02f, 0, C_DARK);
        gpBox(l, .050f, .010f, .010f, .035f, .012f, .08f, 0, C_LIGHT);
        gpBox(l, .018f, .018f, .018f, .064f, .012f, .08f, 0, C_BLACK);
        // Luneta prismatica
        gpBox(l, .020f, .026f, .040f, 0, .037f, -.020f, 0, C_BLACK);
        gpBox(l, .020f, .026f, .040f, 0, .037f, .090f, 0, C_BLACK);
        gpCyl(l, .034f, .19f, 0, .073f, .035f, C_DARK);
        gpCyl(l, .044f, .04f, 0, .073f, -.085f, C_BLACK);
        gpCyl(l, .040f, .03f, 0, .073f, .14f, C_BLACK);
        gpBox(l, .006f, .006f, .14f, 0, .098f, 0, 0, C_ORANGE);
    }

    private void renderViewModel() {
        if (weapon == 4 && adsT > .8f) return;   // o overlay da luneta substitui o modelo
        Gdx.gl.glClear(GL20.GL_DEPTH_BUFFER_BIT);
        viewCam.viewportWidth = Gdx.graphics.getWidth();
        viewCam.viewportHeight = Gdx.graphics.getHeight();
        viewCam.update();
        float[] hp = hipOff[weapon], ap = adsOff[weapon];
        float ox = MathUtils.lerp(hp[0], ap[0], adsT);
        float oy = MathUtils.lerp(hp[1], ap[1], adsT);
        float oz = MathUtils.lerp(hp[2], ap[2], adsT) + kick * .03f;
        viewBase.setToTranslation(ox, oy, oz);
        viewBase.rotate(Vector3.X, kick * 2.5f);
        modelBatch.begin(viewCam);
        for (GunPart p : weaponParts.get(weapon)) {
            p.inst.transform.set(viewBase).mul(p.local);
            modelBatch.render(p.inst, viewEnv);
        }
        modelBatch.end();
    }

    private void ring(float cx, float cy, float r, float th, int seg) {
        float px = cx + r, py = cy;
        for (int i = 1; i <= seg; i++) {
            float ang = MathUtils.PI2 * i / seg;
            float x = cx + MathUtils.cos(ang) * r, y = cy + MathUtils.sin(ang) * r;
            shapes.rectLine(px, py, x, y, th);
            px = x; py = y;
        }
    }

    private void drawSight(float w, float h) {
        int type = weaponSight[weapon];
        float a = MathUtils.clamp((adsT - .3f) / .7f, 0f, 1f);
        float cx = w / 2f, cy = h / 2f;
        Gdx.gl.glEnable(GL20.GL_BLEND);
        Gdx.gl.glBlendFunc(GL20.GL_SRC_ALPHA, GL20.GL_ONE_MINUS_SRC_ALPHA);
        if (type == SIGHT_PRISM) {
            float r = h * .52f;
            if (cx - r > 0) {
                shapes.begin(ShapeRenderer.ShapeType.Filled);
                shapes.setColor(0, 0, 0, a);
                shapes.rect(0, 0, cx - r, h);
                shapes.rect(cx + r, 0, w - cx - r, h);
                shapes.end();
            }
            hud.begin();
            hud.setColor(1, 1, 1, a);
            hud.draw(scopeTex, cx - r, cy - r, 2 * r, 2 * r);
            hud.setColor(Color.WHITE);
            hud.end();
        }
        shapes.begin(ShapeRenderer.ShapeType.Filled);
        if (type == SIGHT_REDDOT) {
            shapes.setColor(1f, .10f, .10f, .25f * a); shapes.circle(cx, cy, h * .013f);
            shapes.setColor(1f, .12f, .12f, a);       shapes.circle(cx, cy, h * .0055f);
        } else if (type == SIGHT_HOLO) {
            float R = h * .035f, th = h * .003f, tk = h * .012f;
            shapes.setColor(.25f, 1f, .35f, a);
            ring(cx, cy, R, th, 48);
            shapes.circle(cx, cy, h * .0045f);
            shapes.rectLine(cx, cy + R, cx, cy + R + tk, th);
            shapes.rectLine(cx, cy - R, cx, cy - R - tk, th);
            shapes.rectLine(cx - R, cy, cx - R - tk, cy, th);
            shapes.rectLine(cx + R, cy, cx + R + tk, cy, th);
        } else if (type == SIGHT_PRISM) {
            float th = h * .0022f, gap = h * .012f, ext = h * .45f;
            shapes.setColor(0, 0, 0, .9f * a);
            shapes.rectLine(cx - ext, cy, cx - gap, cy, th);
            shapes.rectLine(cx + gap, cy, cx + ext, cy, th);
            shapes.rectLine(cx, cy + gap, cx, cy + ext, th);
            shapes.rectLine(cx, cy - gap, cx, cy - ext, th);
            for (int i = 1; i <= 3; i++) {
                float yy = cy - h * .075f * i, len = h * (.022f - .003f * i);
                shapes.rectLine(cx - len, yy, cx + len, yy, th * 1.4f);
            }
            shapes.setColor(1f, .12f, .10f, a);
            shapes.rectLine(cx, cy, cx - h * .022f, cy - h * .032f, th * 2.2f);
            shapes.rectLine(cx, cy, cx + h * .022f, cy - h * .032f, th * 2.2f);
            shapes.circle(cx, cy, h * .0028f);
        }
        shapes.end();
        Gdx.gl.glDisable(GL20.GL_BLEND);
    }

    private void loadCharacters() {
        for (String id : CHAR_IDS) {
            try {
                Texture tex = new Texture(Gdx.files.internal("models/texture-" + id + ".png"));
                tex.setFilter(Texture.TextureFilter.Linear, Texture.TextureFilter.Linear);
                Model m = new ObjLoader().loadModel(Gdx.files.internal("models/character-" + id + ".obj"), false);
                for (Material mat : m.materials) {
                    mat.set(ColorAttribute.createDiffuse(Color.WHITE));
                    mat.set(TextureAttribute.createDiffuse(tex));
                }
                charTextures.add(tex);
                charModels.add(m);
            } catch (Exception ex) {
                Gdx.app.error("StrikeArena", "Falha ao carregar personagem " + id, ex);
            }
        }
    }

    private Model materialBox(float w, float h, float d, Color color) {
        return modelBuilder.createBox(w, h, d,
            new Material(ColorAttribute.createDiffuse(color)),
            VertexAttributes.Usage.Position | VertexAttributes.Usage.Normal);
    }
    private void buildWorld() {
        floorModel = modelBuilder.createBox(85, .2f, 85,
            new Material(ColorAttribute.createDiffuse(new Color(.16f,.16f,.19f,1))),
            VertexAttributes.Usage.Position | VertexAttributes.Usage.Normal);
        wallModel = materialBox(86, 4.8f, 1.4f, new Color(.22f,.24f,.31f,1));
        crateModel = materialBox(2.2f, 1.65f, 2.2f, new Color(.29f,.34f,.42f,1));
        enemyBodyModel = modelBuilder.createCapsule(.32f, 1.1f, 8,
            new Material(ColorAttribute.createDiffuse(new Color(.63f,.13f,.12f,1))),
            VertexAttributes.Usage.Position | VertexAttributes.Usage.Normal);
        enemyHeadModel = modelBuilder.createSphere(.44f,.44f,.44f,8,8,
            new Material(ColorAttribute.createDiffuse(new Color(.78f,.22f,.18f,1))),
            VertexAttributes.Usage.Position | VertexAttributes.Usage.Normal);
        // Textura simples pra arma (metal)
        Pixmap gunPix = new Pixmap(64, 64, Pixmap.Format.RGBA8888);
        for (int y = 0; y < 64; y++) {
            for (int x = 0; x < 64; x++) {
                float n = (x + y * 0.7f) % 16 < 8 ? 0.18f : 0.28f;
                int c = Color.rgba8888(n, n * 1.05f, n * 1.15f, 1f);
                gunPix.setColor(c);
                gunPix.drawPixel(x, y);
            }
        }
        // Destaque no cano
        gunPix.setColor(0.35f, 0.37f, 0.42f, 1f);
        gunPix.fillRectangle(20, 0, 24, 64);
        gunTexture = new Texture(gunPix);
        gunTexture.setFilter(Texture.TextureFilter.Linear, Texture.TextureFilter.Linear);
        gunPix.dispose();
        gunModel = modelBuilder.createBox(.12f, .12f, .42f,
            new Material(TextureAttribute.createDiffuse(gunTexture), ColorAttribute.createDiffuse(Color.WHITE)),
            VertexAttributes.Usage.Position | VertexAttributes.Usage.Normal | VertexAttributes.Usage.TextureCoordinates);
        pickupModel = materialBox(.48f,.14f,.14f,new Color(.10f,.85f,.38f,1));
        staticWorld.add(new ModelInstance(floorModel,0,-.1f,0));
        staticWorld.add(new ModelInstance(wallModel,0,2.4f,-43.5f));
        staticWorld.add(new ModelInstance(wallModel,0,2.4f,43.5f));
        Model sideWall = materialBox(1.4f,4.8f,85,new Color(.22f,.24f,.31f,1));
        staticWorld.add(new ModelInstance(sideWall,-43.5f,2.4f,0));
        staticWorld.add(new ModelInstance(sideWall,43.5f,2.4f,0));
        for (int i=0;i<20;i++) {
            float x=(random.nextFloat()-.5f)*70, z=(random.nextFloat()-.5f)*70;
            if (Math.abs(x)<7 && Math.abs(z)<7) continue;
            ModelInstance box=new ModelInstance(crateModel,x,.82f,z);
            box.transform.rotate(Vector3.Y,random.nextFloat()*360);
            staticWorld.add(box);
        }
    }

    @Override public void render() {
        float dt=Math.min(Gdx.graphics.getDeltaTime(),.05f);
        worldTime += dt;
        if (screen == Screen.PLAYING) updateGame(dt);
        Gdx.gl.glViewport(0,0,Gdx.graphics.getWidth(),Gdx.graphics.getHeight());
        Gdx.gl.glClearColor(.025f,.025f,.055f,1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT | GL20.GL_DEPTH_BUFFER_BIT);
        camera.update();
        modelBatch.begin(camera);
        for (ModelInstance m: staticWorld) modelBatch.render(m,environment);
        for (Enemy e: enemies) { modelBatch.render(e.body,environment); if (e.head != null) modelBatch.render(e.head,environment); }
        for (Pickup p: pickups) modelBatch.render(p.model,environment);
        modelBatch.end();
        if (screen == Screen.PLAYING) renderViewModel();
        drawHud();
        if (mobile) drawTouchPointers();
    }

    private void updateGame(float dt) {
        if (mobile && firing) fire();
        updateMovement(dt);
        spawnTimer += dt;
        if (spawnTimer >= 2.7f && enemies.size < 10) { spawnTimer=0; spawnEnemy(); }
        for (int i=enemies.size-1;i>=0;i--) {
            Enemy e=enemies.get(i);
            Vector3 to=camera.position.cpy().sub(e.position); to.y=0;
            float faceX=to.x, faceZ=to.z;
            float dist=to.len();
            if (dist>1.55f) { to.nor().scl(e.speed*dt); e.position.add(to); }
            if (e.skinned) {
                float ang = MathUtils.atan2(faceX, faceZ) * MathUtils.radiansToDegrees;
                e.body.transform.idt().translate(e.position.x, e.position.y, e.position.z).rotate(Vector3.Y, ang).scale(CHAR_SCALE, CHAR_SCALE, CHAR_SCALE);
            } else {
                e.body.transform.setToTranslation(e.position.x,e.position.y+.75f,e.position.z);
                e.head.transform.setToTranslation(e.position.x,e.position.y+1.55f,e.position.z);
            }
            e.attackTimer-=dt;
            if (dist<1.85f && e.attackTimer<=0) { e.attackTimer=1; damagePlayer(10); }
        }
        for (int i=pickups.size-1;i>=0;i--) {
            Pickup p=pickups.get(i);
            p.phase += dt;
            p.model.transform.setToTranslation(p.position.x,.55f+MathUtils.sin(p.phase*2.2f)*.09f,p.position.z);
            p.model.transform.rotate(Vector3.Y,dt*70);
            if (p.position.dst(camera.position.x,0,camera.position.z)<1.2f) {
                hp=Math.min(100,hp+28); pickups.removeIndex(i);
            }
        }
        if (worldTime-lastDamage>3.8f && hp<100) { regenTimer+=7*dt; if(regenTimer>=1){hp=Math.min(100,hp+1);regenTimer=0;} }
    }

    private void updateMovement(float dt) {
        float mx=0,mz=0;
        if (mobile) { mx=moveX; mz=moveY; }
        else {
            if(moveForward) mz-=1; if(moveBack) mz+=1; if(moveLeft) mx-=1; if(moveRight) mx+=1;
        }
        float len=(float)Math.sqrt(mx*mx+mz*mz); if(len>1){mx/=len;mz/=len;}
        forward.set(camera.direction.x,0,camera.direction.z).nor();
        right.set(forward).crs(Vector3.Y).nor();
        move.set(forward).scl(-mz).mulAdd(right,mx).scl(7.8f);
        camera.position.mulAdd(move,dt);
        velocity.y-=28*dt;
        camera.position.y+=velocity.y*dt;
        if(camera.position.y<1.7f){camera.position.y=1.7f;velocity.y=0;}
        camera.position.x=MathUtils.clamp(camera.position.x,-40,40);
        camera.position.z=MathUtils.clamp(camera.position.z,-40,40);
        if (mobile && (lookX!=0 || lookY!=0)) {
            float fs = MathUtils.clamp(camera.fieldOfView/75f,.2f,1f);
            yaw -= lookX*.0038f*sens*fs;  // corrige eixo X invertido
            pitch -= lookY*.0038f*sens*fs;
            lookX=lookY=0;
        }
        if (jumpRequested && camera.position.y<=1.71f) velocity.y=11;
        jumpRequested=false;
        pitch=MathUtils.clamp(pitch,-1.35f,1.35f);
        // Eixos da câmera corrigidos: yaw positivo = virar pra direita, pitch positivo = olhar pra cima
        camera.direction.set(
            -MathUtils.sin(yaw) * MathUtils.cos(pitch),
            MathUtils.sin(pitch),
            -MathUtils.cos(yaw) * MathUtils.cos(pitch)
        ).nor();
        camera.up.set(Vector3.Y);
        camera.fieldOfView += ((ads?weaponAdsFov[weapon]:75)-camera.fieldOfView)*Math.min(1,dt*10);
        adsT += ((ads?1f:0f)-adsT)*Math.min(1f,dt*11f);
        kick = Math.max(0f,kick-dt*7f);
    }

    private void spawnEnemy() {
        Enemy e=new Enemy();
        float x,z;
        do { x=(random.nextFloat()-.5f)*72; z=(random.nextFloat()-.5f)*72; }
        while (Vector2.dst(x,z,camera.position.x,camera.position.z)<16);
        e.position.set(x,0,z); e.speed=3.5f*(.85f+random.nextFloat()*.3f);
        if (charModels.size > 0) {
            e.body=new ModelInstance(charModels.get(random.nextInt(charModels.size)));
            e.skinned=true;
        } else {
            e.body=new ModelInstance(enemyBodyModel); e.head=new ModelInstance(enemyHeadModel);
        }
        enemies.add(e);
    }

    private void fire() {
        if(screen!=Screen.PLAYING || ammo<=0 || worldTime-lastShot<weaponRate[weapon]) return;
        lastShot=worldTime; ammo--; kick=1f;
        Vector3 dir=camera.direction.cpy().nor();
        Enemy hit=null; float best=90;
        for(Enemy e:enemies) {
            Vector3 target=e.position.cpy().add(0,1.15f,0);
            Vector3 to=target.sub(camera.position);
            float distance=to.len(); to.nor();
            float dot=dir.dot(to);
            if(dot>.992f && distance<best) { best=distance; hit=e; }
        }
        if(hit!=null) {
            hit.hp-=weaponDamage[weapon]*(ads?1.15f:1);
            if(hit.hp<=0) {
                enemies.removeValue(hit,true); kills++; money+=50+random.nextInt(30);
                if(random.nextFloat()<.4f && pickups.size<5) {
                    Pickup p=new Pickup(); p.position.set(hit.position); p.model=new ModelInstance(pickupModel); pickups.add(p);
                }
            }
        }
    }

    private void damagePlayer(int amount) {
        hp=Math.max(0,hp-amount); lastDamage=worldTime; regenTimer=0;
        if(hp<=0) { screen=Screen.DEAD; firing=false; ads=false; unlockMouse(); }
    }

    private void startGame() {
        screen=Screen.PLAYING; hp=100; kills=0; money=0; ammo=weaponAmmo[weapon];
        enemies.clear(); pickups.clear(); camera.position.set(0,1.7f,0); yaw=pitch=0; velocity.setZero();
        spawnTimer=0; lockMouse();
    }
    private void restart() { startGame(); }
    private void lockMouse() { if(!mobile) Gdx.input.setCursorCatched(true); }
    private void unlockMouse() { Gdx.input.setCursorCatched(false); }

    private void drawHud() {
        float w=Gdx.graphics.getWidth(), h=Gdx.graphics.getHeight();
        hud.begin();
        if(screen==Screen.PLAYING) {
            font.setColor(Color.WHITE);
            font.draw(hud,"VIDA  "+hp,w*.025f,h*.96f);
            font.draw(hud,"MUNIÇÃO  "+ammo,w*.43f,h*.96f);
            font.setColor(Color.GOLD); font.draw(hud,"$"+money,w*.75f,h*.96f);
            font.setColor(Color.WHITE); font.draw(hud,"KILLS  "+kills,w*.88f,h*.96f);
            font.draw(hud,weaponNames[weapon]+(weaponSight[weapon]!=SIGHT_NONE?"  -  "+sightLabel[weaponSight[weapon]]:""),w*.40f,h*.08f);
            hud.end();
            if (weaponSight[weapon]!=SIGHT_NONE && adsT>.3f) {
                drawSight(w,h);
            } else {
                shapes.begin(ShapeRenderer.ShapeType.Line);
                shapes.setColor(Color.WHITE);
                float cx=w/2,cy=h/2;
                shapes.line(cx-9,cy,cx-3,cy); shapes.line(cx+3,cy,cx+9,cy);
                shapes.line(cx,cy-9,cx,cy-3); shapes.line(cx,cy+3,cx,cy+9);
                shapes.end();
            }
            if(mobile) drawTouchControls(w,h);
            return;
        }
        hud.end();
        drawPanel(w,h);
    }

    private void layoutTouch(float w,float h) {
        jR=h*.16f; jX=jR*1.3f+h*.04f; jY=jX;
        fR=h*.115f; fX=w-h*.25f; fY=h*.27f;
        pR=h*.075f; pX=fX; pY=fY+h*.25f;
        aR=h*.075f; aX=fX-h*.23f; aY=fY+h*.04f;
        rR=h*.075f; rX=fX-h*.21f; rY=fY+h*.25f;
        // Botão de pause no canto superior direito
        pauseR = h * .055f;
        pauseX = w - h * .09f;
        pauseY = h - h * .09f;
    }
    private boolean hit(float x,float y,float cx,float cy,float r) {
        float dx=x-cx, dy=y-cy;
        return dx*dx+dy*dy <= r*r*1.3f;
    }
    private void updateStick(float x,float yy) {
        float h=Gdx.graphics.getHeight(), w=Gdx.graphics.getWidth();
        layoutTouch(w,h);
        float dx=(x-jX)/jR, dy=(jY-yy)/jR;
        float len=(float)Math.sqrt(dx*dx+dy*dy);
        if(len>1){dx/=len;dy/=len;}
        moveX=dx; moveY=dy;
    }
    private void centerLabel(String text,float cx,float cy) {
        layout.setText(font,text);
        font.draw(hud,layout,cx-layout.width/2f,cy+layout.height/2f);
    }

    private void drawTouchControls(float w,float h) {
        layoutTouch(w,h);
        Gdx.gl.glEnable(GL20.GL_BLEND);
        Gdx.gl.glBlendFunc(GL20.GL_SRC_ALPHA,GL20.GL_ONE_MINUS_SRC_ALPHA);
        shapes.begin(ShapeRenderer.ShapeType.Filled);
        float kr=jR*.4f;
        shapes.setColor(1,1,1,.12f); shapes.circle(jX,jY,jR);
        shapes.setColor(1,1,1,.35f); shapes.circle(jX+moveX*(jR-kr),jY-moveY*(jR-kr),kr);
        shapes.setColor(1,.28f,.34f,firing?.85f:.55f); shapes.circle(fX,fY,fR);
        shapes.setColor(1,1,1,.22f); shapes.circle(pX,pY,pR);
        shapes.setColor(1,1,1,ads?.50f:.22f); shapes.circle(aX,aY,aR);
        shapes.setColor(1,1,1,.22f); shapes.circle(rX,rY,rR);
        // Botão pause
        shapes.setColor(.9f,.3f,.3f,.55f); shapes.circle(pauseX,pauseY,pauseR);
        shapes.end();
        hud.begin();
        float sx=font.getData().scaleX, sy=font.getData().scaleY;
        font.getData().setScale(h/720f);
        font.setColor(Color.WHITE);
        centerLabel("TIRO",fX,fY); centerLabel("PULAR",pX,pY);
        centerLabel("MIRA",aX,aY); centerLabel("R",rX,rY);
        font.getData().setScale(h/900f);
        centerLabel("||",pauseX,pauseY);
        font.getData().setScale(sx,sy);
        hud.end();
        Gdx.gl.glDisable(GL20.GL_BLEND);
    }

    private void drawTouchPointers() {
        float h=Gdx.graphics.getHeight();
        Gdx.gl.glEnable(GL20.GL_BLEND);
        Gdx.gl.glBlendFunc(GL20.GL_SRC_ALPHA,GL20.GL_ONE_MINUS_SRC_ALPHA);
        shapes.begin(ShapeRenderer.ShapeType.Filled);
        shapes.setColor(1,1,1,.55f);
        for(int i=0;i<5;i++) {
            if(Gdx.input.isTouched(i)) shapes.circle(Gdx.input.getX(i),h-Gdx.input.getY(i),h*.045f);
        }
        shapes.end();
        Gdx.gl.glDisable(GL20.GL_BLEND);
    }

    private void drawButton(float x, float y, float bw, float bh, Color bg, Color border) {
        shapes.setColor(border);
        shapes.rect(x - 2, y - 2, bw + 4, bh + 4);
        shapes.setColor(bg);
        shapes.rect(x, y, bw, bh);
    }

    private void drawPanel(float w, float h) {
        shapes.begin(ShapeRenderer.ShapeType.Filled);
        // Fundo escuro
        shapes.setColor(0, 0, 0, 0.85f);
        shapes.rect(0, 0, w, h);
        // Painel central mais polido
        shapes.setColor(0.06f, 0.06f, 0.10f, 0.97f);
        shapes.rect(w * 0.22f, h * 0.12f, w * 0.56f, h * 0.76f);
        // Borda sutil
        shapes.setColor(0.25f, 0.25f, 0.35f, 0.6f);
        shapes.rect(w * 0.22f, h * 0.12f, w * 0.56f, 3);
        shapes.rect(w * 0.22f, h * 0.88f - 3, w * 0.56f, 3);

        float btnW = w * 0.38f;
        float btnH = h * 0.075f;
        float btnX = w * 0.31f;

        if (screen == Screen.MENU) {
            // Botões sólidos
            drawButton(btnX, h * 0.48f, btnW, btnH, new Color(0.15f, 0.45f, 0.25f, 1f), new Color(0.3f, 0.7f, 0.4f, 1f));
            drawButton(btnX, h * 0.36f, btnW, btnH, new Color(0.25f, 0.28f, 0.45f, 1f), new Color(0.4f, 0.45f, 0.7f, 1f));
        } else if (screen == Screen.DEAD) {
            drawButton(btnX, h * 0.42f, btnW, btnH, new Color(0.15f, 0.45f, 0.25f, 1f), new Color(0.3f, 0.7f, 0.4f, 1f));
            drawButton(btnX, h * 0.30f, btnW, btnH, new Color(0.25f, 0.28f, 0.45f, 1f), new Color(0.4f, 0.45f, 0.7f, 1f));
            drawButton(btnX, h * 0.18f, btnW, btnH, new Color(0.35f, 0.18f, 0.18f, 1f), new Color(0.6f, 0.3f, 0.3f, 1f));
        } else if (screen == Screen.PAUSED) {
            drawButton(btnX, h * 0.52f, btnW, btnH, new Color(0.15f, 0.45f, 0.25f, 1f), new Color(0.3f, 0.7f, 0.4f, 1f));
            drawButton(btnX, h * 0.40f, btnW, btnH, new Color(0.25f, 0.28f, 0.45f, 1f), new Color(0.4f, 0.45f, 0.7f, 1f));
            drawButton(btnX, h * 0.28f, btnW, btnH * 0.7f, new Color(0.35f, 0.18f, 0.18f, 1f), new Color(0.6f, 0.3f, 0.3f, 1f));

            // Barra de sensibilidade
            float barX = w * 0.30f;
            float barW = w * 0.40f;
            float barY = h * 0.17f;
            float barH = h * 0.032f;
            float t = MathUtils.clamp((sens - sensMin) / (sensMax - sensMin), 0f, 1f);
            float knobX = barX + t * barW;
            shapes.setColor(0.12f, 0.12f, 0.18f, 1f);
            shapes.rect(barX, barY, barW, barH);
            shapes.setColor(0.85f, 0.25f, 0.30f, 1f);
            shapes.rect(barX, barY, t * barW, barH);
            shapes.setColor(1f, 1f, 1f, 1f);
            shapes.circle(knobX, barY + barH * 0.5f, barH * 0.9f);
        } else if (screen == Screen.SHOP) {
            // Botões de armas com "ícones" (retângulos coloridos)
            for (int i = 0; i < weaponNames.length; i++) {
                float by = h * (0.58f - i * 0.085f);
                Color bg = weaponOwned[i] ? (weapon == i ? new Color(0.15f, 0.4f, 0.25f, 1f) : new Color(0.18f, 0.18f, 0.25f, 1f))
                        : new Color(0.22f, 0.18f, 0.15f, 1f);
                drawButton(w * 0.28f, by, w * 0.44f, h * 0.07f, bg, new Color(0.4f, 0.4f, 0.5f, 0.8f));
                // Ícone simples da arma (retângulo)
                shapes.setColor(0.5f, 0.55f, 0.65f, 1f);
                shapes.rect(w * 0.30f, by + h * 0.018f, w * 0.045f, h * 0.035f);
            }
            // Botão voltar
            drawButton(btnX, h * 0.14f, btnW, btnH * 0.85f, new Color(0.3f, 0.15f, 0.15f, 1f), new Color(0.55f, 0.25f, 0.25f, 1f));
        }
        shapes.end();

        // Textos
        hud.begin();
        font.setColor(red);
        String title = screen == Screen.MENU ? "STRIKE ARENA" : screen == Screen.PAUSED ? "PAUSADO" :
                screen == Screen.SHOP ? "LOJA" : "VOCÊ MORREU";
        font.getData().setScale(2.2f);
        drawCentered(title, w, h * 0.78f);
        font.getData().setScale(1.15f);

        if (screen == Screen.MENU) {
            font.setColor(Color.LIGHT_GRAY);
            drawCentered("FPS 3D  •  PC + ANDROID", w, h * 0.68f);
            font.setColor(Color.WHITE);
            drawCentered("JOGAR", w, h * 0.48f + btnH * 0.65f);
            drawCentered("LOJA", w, h * 0.36f + btnH * 0.65f);
        } else if (screen == Screen.DEAD) {
            font.setColor(Color.GOLD);
            drawCentered("Kills: " + kills + "   $ " + money, w, h * 0.62f);
            font.setColor(Color.WHITE);
            drawCentered("JOGAR NOVAMENTE", w, h * 0.42f + btnH * 0.65f);
            drawCentered("LOJA", w, h * 0.30f + btnH * 0.65f);
            drawCentered("MENU PRINCIPAL", w, h * 0.18f + btnH * 0.65f);
        } else if (screen == Screen.PAUSED) {
            font.setColor(Color.WHITE);
            drawCentered("CONTINUAR", w, h * 0.52f + btnH * 0.65f);
            drawCentered("LOJA", w, h * 0.40f + btnH * 0.65f);
            drawCentered("MENU", w, h * 0.28f + btnH * 0.55f);
            font.setColor(Color.LIGHT_GRAY);
            drawCentered("SENS: " + String.format("%.1f", sens), w, h * 0.12f);
        } else if (screen == Screen.SHOP) {
            font.setColor(Color.GOLD);
            drawCentered("SALDO: $" + money, w, h * 0.70f);
            font.setColor(Color.WHITE);
            for (int i = 0; i < weaponNames.length; i++) {
                float by = h * (0.58f - i * 0.085f);
                String state = weaponOwned[i] ? (weapon == i ? "EQUIPADA" : "POSSUI") : "$" + weaponPrice[i];
                // Ícone textual + nome
                String icon = i == 0 ? "[P]" : i == 1 ? "[S]" : i == 2 ? "[R]" : i == 3 ? "[G]" : "[N]";
                font.draw(hud, icon + "  " + weaponNames[i] + "   " + state, w * 0.36f, by + h * 0.048f);
            }
            drawCentered("VOLTAR", w, h * 0.14f + btnH * 0.55f);
        }
        hud.end();
    }
    private void drawCentered(String s, float w, float y) {
        layout.setText(font, s);
        font.draw(hud, layout, w / 2f - layout.width / 2f, y);
    }

    private void openShop() { screen=Screen.SHOP; unlockMouse(); }
    private void buyWeapon(int i) {
        if(i<0||i>=weaponNames.length)return;
        if(weaponOwned[i]) { weapon=i; ammo=weaponAmmo[i]; }
        else if(money>=weaponPrice[i]) { money-=weaponPrice[i]; weaponOwned[i]=true; weapon=i; ammo=weaponAmmo[i]; }
    }
    private void buySight(int i) {
        if(i<0||i>=sightNames.length)return;
        if(sightOwned[i]) sight=i;
        else if(money>=sightPrice[i]) {money-=sightPrice[i];sightOwned[i]=true;sight=i;}
    }

    @Override public boolean keyDown(int key) {
        if(key==Input.Keys.W)moveForward=true; if(key==Input.Keys.S)moveBack=true;
        if(key==Input.Keys.A)moveLeft=true; if(key==Input.Keys.D)moveRight=true;
        if(key==Input.Keys.SPACE)jumpRequested=true;
        if(key==Input.Keys.R && screen==Screen.PLAYING)ammo=weaponAmmo[weapon];
        if(key==Input.Keys.ESCAPE || key==Input.Keys.BACK) {
            if(screen==Screen.PLAYING){screen=Screen.PAUSED;unlockMouse();}
            else if(screen==Screen.PAUSED){screen=Screen.MENU;}
            else if(screen==Screen.SHOP){screen=Screen.MENU;}
            else if(screen==Screen.DEAD){screen=Screen.MENU;}
        }
        if(key==Input.Keys.ENTER) {
            if(screen==Screen.MENU||screen==Screen.DEAD)startGame();
            else if(screen==Screen.PAUSED){screen=Screen.PLAYING;lockMouse();}
        }
        if(key==Input.Keys.L && screen!=Screen.PLAYING)openShop();
        if(key==Input.Keys.Q && screen==Screen.SHOP)screen=Screen.MENU;
        if(screen==Screen.SHOP && key>=Input.Keys.NUM_1 && key<=Input.Keys.NUM_5)buyWeapon(key-Input.Keys.NUM_1);
        if(key==Input.Keys.TAB && screen==Screen.PLAYING)ads=!ads;
        return false;
    }
    @Override public boolean keyUp(int key) {
        if(key==Input.Keys.W)moveForward=false; if(key==Input.Keys.S)moveBack=false;
        if(key==Input.Keys.A)moveLeft=false; if(key==Input.Keys.D)moveRight=false;
        return false;
    }
    @Override public boolean touchDown(int x, int y, int pointer, int button) {
        float w = Gdx.graphics.getWidth(), h = Gdx.graphics.getHeight();
        float yy = h - y;
        float btnW = w * 0.38f;
        float btnH = h * 0.075f;
        float btnX = w * 0.31f;

        // ===== MENU PRINCIPAL =====
        if (screen == Screen.MENU) {
            // Botão JOGAR
            if (x >= btnX && x <= btnX + btnW && yy >= h * 0.48f && yy <= h * 0.48f + btnH) {
                startGame();
                return true;
            }
            // Botão LOJA
            if (x >= btnX && x <= btnX + btnW && yy >= h * 0.36f && yy <= h * 0.36f + btnH) {
                openShop();
                return true;
            }
            return true; // não inicia mais clicando fora
        }

        // ===== TELA DE MORTE =====
        if (screen == Screen.DEAD) {
            if (x >= btnX && x <= btnX + btnW && yy >= h * 0.42f && yy <= h * 0.42f + btnH) {
                startGame();
                return true;
            }
            if (x >= btnX && x <= btnX + btnW && yy >= h * 0.30f && yy <= h * 0.30f + btnH) {
                openShop();
                return true;
            }
            if (x >= btnX && x <= btnX + btnW && yy >= h * 0.18f && yy <= h * 0.18f + btnH) {
                screen = Screen.MENU;
                return true;
            }
            return true; // não inicia clicando fora
        }

        // ===== PAUSE =====
        if (screen == Screen.PAUSED) {
            // Barra de sensibilidade
            float barX = w * 0.30f;
            float barW = w * 0.40f;
            float barY = h * 0.17f;
            float barH = h * 0.032f;
            float pad = barH * 2f;
            if (x >= barX - pad && x <= barX + barW + pad && yy >= barY - pad && yy <= barY + barH + pad) {
                draggingSens = true;
                float t = MathUtils.clamp((x - barX) / barW, 0f, 1f);
                sens = sensMin + t * (sensMax - sensMin);
                return true;
            }
            // CONTINUAR
            if (x >= btnX && x <= btnX + btnW && yy >= h * 0.52f && yy <= h * 0.52f + btnH) {
                screen = Screen.PLAYING;
                lockMouse();
                return true;
            }
            // LOJA
            if (x >= btnX && x <= btnX + btnW && yy >= h * 0.40f && yy <= h * 0.40f + btnH) {
                openShop();
                return true;
            }
            // MENU
            if (x >= btnX && x <= btnX + btnW && yy >= h * 0.28f && yy <= h * 0.28f + btnH * 0.7f) {
                screen = Screen.MENU;
                return true;
            }
            return true;
        }

        // ===== LOJA =====
        if (screen == Screen.SHOP) {
            // Botões de armas
            for (int i = 0; i < weaponNames.length; i++) {
                float by = h * (0.58f - i * 0.085f);
                if (x >= w * 0.28f && x <= w * 0.72f && yy >= by && yy <= by + h * 0.07f) {
                    buyWeapon(i);
                    return true;
                }
            }
            // VOLTAR
            if (x >= btnX && x <= btnX + btnW && yy >= h * 0.14f && yy <= h * 0.14f + btnH * 0.85f) {
                screen = Screen.MENU;
                return true;
            }
            return true;
        }

        // ===== JOGO =====
        if (mobile) {
            layoutTouch(w, h);
            if (hit(x, yy, pauseX, pauseY, pauseR)) {
                screen = Screen.PAUSED;
                unlockMouse();
                return true;
            }
            if (hit(x, yy, fX, fY, fR)) { firePointer = pointer; firing = true; fire(); }
            else if (hit(x, yy, pX, pY, pR)) { jumpRequested = true; }
            else if (hit(x, yy, aX, aY, aR)) { ads = !ads; }
            else if (hit(x, yy, rX, rY, rR)) { ammo = weaponAmmo[weapon]; }
            else if (x < w * 0.42f && yy < h * 0.62f) { movePointer = pointer; updateStick(x, yy); }
            else { lookPointer = pointer; touchStartX = x; touchStartY = y; }
        } else {
            if (button == Input.Buttons.LEFT) fire();
            if (button == Input.Buttons.RIGHT) ads = true;
        }
        return true;
    }
    @Override public boolean touchUp(int x,int y,int pointer,int button) {
        if(pointer==movePointer){movePointer=-1;moveX=moveY=0;}
        if(pointer==lookPointer)lookPointer=-1;
        if(pointer==firePointer){firePointer=-1;firing=false;}
        draggingSens = false;
        if(!mobile && button==Input.Buttons.RIGHT) ads=false;
        return true;
    }
    @Override public boolean touchDragged(int x,int y,int pointer) {
        if (draggingSens && screen == Screen.PAUSED) {
            float w = Gdx.graphics.getWidth();
            float barX = w * 0.32f;
            float barW = w * 0.36f;
            float t = MathUtils.clamp((x - barX) / barW, 0f, 1f);
            sens = sensMin + t * (sensMax - sensMin);
            return true;
        }
        if(mobile) {
            if(pointer==movePointer) {
                updateStick(x,Gdx.graphics.getHeight()-y);
            } else if(pointer==lookPointer) {
                lookX+=x-touchStartX; lookY+=y-touchStartY; touchStartX=x; touchStartY=y;
            }
        }
        return true;
    }
    @Override public boolean mouseMoved(int x,int y) {
        if(!mobile&&screen==Screen.PLAYING&&Gdx.input.isCursorCatched()) {
            float fs = MathUtils.clamp(camera.fieldOfView/75f,.2f,1f);
            yaw -= Gdx.input.getDeltaX()*.0022f*sens*fs;  // corrige eixo X invertido
            pitch -= Gdx.input.getDeltaY()*.0022f*sens*fs;
        }
        return false;
    }
    @Override public boolean scrolled(float amountX,float amountY){return false;}
    @Override public boolean touchCancelled(int x,int y,int pointer,int button){return touchUp(x,y,pointer,button);}
    @Override public boolean keyTyped(char c){return false;}

    @Override public void resize(int width,int height) {
        if(camera!=null){camera.viewportWidth=width;camera.viewportHeight=height;camera.update();}
        if(shapes!=null){shapes.getProjectionMatrix().setToOrtho2D(0,0,width,height);shapes.updateMatrices();}
        if(hud!=null){hud.getProjectionMatrix().setToOrtho2D(0,0,width,height);hud.setProjectionMatrix(hud.getProjectionMatrix());}
    }
    @Override public void dispose() {
        modelBatch.dispose(); hud.dispose(); shapes.dispose(); font.dispose();
        floorModel.dispose(); wallModel.dispose(); crateModel.dispose(); enemyBodyModel.dispose();
        enemyHeadModel.dispose(); gunModel.dispose(); pickupModel.dispose();
        if (gunTexture != null) gunTexture.dispose();
        for (Model m : charModels) m.dispose();
        for (Model m : gunModels) m.dispose();
        if (scopeTex != null) scopeTex.dispose();
        for (Texture t : charTextures) t.dispose();
    }
}
