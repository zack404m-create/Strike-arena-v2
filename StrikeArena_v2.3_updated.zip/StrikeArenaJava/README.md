# Strike Arena — Java / LibGDX

Port inicial do protótipo HTML enviado para Java com LibGDX, preparado para desktop e Android.

## Requisitos
- JDK 17
- Android Studio (para compilar Android)
- Gradle 8.7+ (ou use o Gradle integrado do Android Studio)

## Executar no PC
Na pasta do projeto:
```bash
gradle :lwjgl3:run
```

## Abrir no Android
1. Abra a pasta do projeto no Android Studio.
2. Aguarde a sincronização do Gradle.
3. Selecione a configuração `android` e execute em um dispositivo/emulador Android.

## Controles
### PC
- WASD: movimentar
- Mouse: olhar
- Clique esquerdo: atirar
- Clique direito: mira
- Espaço: pular
- R: recarregar
- Tab: alternar mira
- Esc: pausar
- L: loja (nas telas de menu/pausa)
- 1 a 5: comprar/equipar armas na loja

### Android
- Analógico esquerdo: movimentar
- Arraste no lado direito: olhar
- Botões na direita: tiro, pulo, mira e recarga

## Observações
Esta é uma conversão-base funcional da estrutura e das mecânicas principais. O protótipo original usa Three.js no navegador; LibGDX usa renderização nativa Java, então materiais, modelos, HUD e controles foram recriados em vez de traduzidos linha por linha. A loja de miras, áudio avançado, colisões detalhadas e balanceamento podem ser refinados em uma próxima versão.

## Atualizações recentes
- Textura do terreno em tons de verde mais vivos.
- Colisão das caixas com cobertura da face superior para pouso ao saltar.
- No Android, o botão **MUDAR NOME** abre o teclado nativo apenas para essa ação; o nome fica salvo localmente.
- Lobby com personagem 3D aleatório, cuja escolha fica salva por instalação/dispositivo.
